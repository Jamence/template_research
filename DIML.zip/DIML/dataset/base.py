
from __future__ import print_function
from __future__ import division

import os
import torch
import torchvision
import numpy as np
import PIL.Image
from copy import deepcopy

class BaseDataset(torch.utils.data.Dataset):
    def __init__(self, root, mode, base_transform = None, advanced_transform = None):
        self.root = root
        self.mode = mode
        self.base_transform = base_transform
        self.advanced_transform = advanced_transform
        self.ys, self.im_paths, self.I = [], [], []

    def nb_classes(self):
        assert set(self.ys) == set(self.classes)
        return len(self.classes)

    def __len__(self):
        return len(self.ys)

    def __getitem__(self, index):
        def img_load(index):
            im = PIL.Image.open(self.im_paths[index])
            # convert gray to rgb
            if len(list(im.split())) == 1 : im = im.convert('RGB')

            im_1 = im
            if self.base_transform is not None:
                im_1 = self.base_transform(im)

            transform_im = deepcopy(im)
            if self.advanced_transform is not None:
                transform_im = self.advanced_transform(transform_im)

            return im_1, transform_im

        im, transform_im = img_load(index)
        target = self.ys[index]
        if self.mode == 'train' :
            return im, transform_im, target
        else :
            return im, target

    def get_label(self, index):
        return self.ys[index]

    def set_subset(self, I):
        self.ys = [self.ys[i] for i in I]
        self.I = [self.I[i] for i in I]
        self.im_paths = [self.im_paths[i] for i in I]