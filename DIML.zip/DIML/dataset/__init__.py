from .cars import Cars
# from .cars_crop import Cars_crop
from .cub import CUBirds
# from .cub_crop import CUBirds_crop
from .SOP import SOP
from .import utils
from .base import BaseDataset


_type = {
    'cars': Cars,
    'cub': CUBirds,
    'SOP': SOP
    # 'cars_crop': Cars_crop,
    # 'cub_crop': CUBirds_crop
}

def load(name, root, mode, base_transform = None, advanced_transform = None):
    return _type[name](root = root, mode = mode, base_transform = base_transform, advanced_transform = advanced_transform)