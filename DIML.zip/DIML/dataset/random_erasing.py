from __future__ import absolute_import

from torchvision.transforms import *

from PIL import Image
import random
import math
import numpy as np
import torch

class RandomErasing(object):
    """ Randomly selects a rectangle region in an image and erases its pixels.
        'Random Erasing Data Augmentation' by Zhong et al.
        See https://arxiv.org/pdf/1708.04896.pdf
    Args:
         probability: The probability that the Random Erasing operation will be performed.
         sl: Minimum proportion of erased area against input image.
         sh: Maximum proportion of erased area against input image.
         r1: Minimum aspect ratio of erased area.
         mean: Erasing value. 
    """
    
    def __init__(self, probability = 0.5, sl = 0.02, sh = 0.4, r1 = 0.3, mean=[0.485, 0.456, 0.406]):
        self.probability = probability
        self.mean = mean
        self.sl = sl
        self.sh = sh
        self.r1 = r1
       
    def __call__(self, img):
        # print("type is ", type(img), img.shape)
        if random.uniform(0, 1) > self.probability:
            return img

        for attempt in range(100):
            area = img.size()[1] * img.size()[2]
       
            target_area = random.uniform(self.sl, self.sh) * area
            aspect_ratio = random.uniform(self.r1, 1/self.r1)

            h = int(round(math.sqrt(target_area * aspect_ratio)))
            w = int(round(math.sqrt(target_area / aspect_ratio)))

            if w < img.size()[2] and h < img.size()[1]:
                x1 = random.randint(0, img.size()[1] - h)
                y1 = random.randint(0, img.size()[2] - w)
                if img.size()[0] == 3:
                    img[0, x1:x1+h, y1:y1+w] = self.mean[0]
                    img[1, x1:x1+h, y1:y1+w] = self.mean[1]
                    img[2, x1:x1+h, y1:y1+w] = self.mean[2]
                else:
                    img[0, x1:x1+h, y1:y1+w] = self.mean[0]
                return img

        return img

class Cutout(object):
    def __init__(self, probability=0.5, size=64, mean=[0.4914, 0.4822, 0.4465]):
        self.probability = probability
        self.mean = mean
        self.size = size

    def __call__(self, img):

        if random.uniform(0, 1) > self.probability:
            return img

        h = self.size
        w = self.size
        for attempt in range(100):
            area = img.size()[1] * img.size()[2]
            if w < img.size()[2] and h < img.size()[1]:
                x1 = random.randint(0, img.size()[1] - h)
                y1 = random.randint(0, img.size()[2] - w)
                if img.size()[0] == 3:
                    img[0, x1:x1 + h, y1:y1 + w] = self.mean[0]
                    img[1, x1:x1 + h, y1:y1 + w] = self.mean[1]
                    img[2, x1:x1 + h, y1:y1 + w] = self.mean[2]
                else:
                    img[0, x1:x1 + h, y1:y1 + w] = self.mean[0]
                return img
        return img

class SelfMix(object) :
    def __init__(self, wlength, hlength):
        self.wlength = wlength
        self.hlength = hlength

    def Clip(self, x1, x2, y1, y2, W, H):
        if x1 < 0 :
            x1 = 0
        if x2 > W :
            x2 = W
        if y1 < 0 :
            y1 = 0
        if y2 > H :
            y2 = H
        return x1, x2, y1, y2

    def __call__(self, img):
        W = img.size()[1]
        H = img.size()[2]
        x = random.randint(0, W)
        y = random.randint(0, H)
        x1, x2, y1, y2 = int(x - self.wlength/2), int(x + self.wlength/2), int(y - self.hlength/2), int(y + self.hlength/2)
        x1, x2, y1, y2 = self.Clip(x1, x2, y1, y2, W, H)
        while True :
            xn = random.randint(int(0 + (x2 - x1)), int(W - (x2 - x1)))
            yn = random.randint(int(0 + (y2 - y1)), int(H - (y2 - y1)))
            if yn != y1 or xn != x1 :
                break

        # print(xn, xn + (x2 - x1), yn, yn+(y2-y1))
        tmp = img[:, x1: x2, y1: y2]
        img[:, x1: x2, y1: y2] = img[:, xn: xn + (x2 - x1), yn: yn + (y2 - y1)]
        img[:, xn: xn + (x2 - x1), yn: yn + (y2 - y1)] = tmp
        return img

class RRP(object) :
    def __init__(self, probability=0.0):
        """
        :param probability:表示原图占合成图片的比例
        """
        self.probability = probability

    def __call__(self, data1, data2, targets):

        if self.probability == 1.0 :
            return data1, data2, targets
        ### 随机选择遮挡物id
        indices = torch.randperm(data1.size(0))
        shuffled_data1 = data1[indices]
        shuffled_data2 = data2[indices]

        ### 随机选择图片中一部分
        image_h, image_w = data1.shape[2:]
        cx = np.random.uniform(0, image_w)
        cy = np.random.uniform(0, image_h)
        w = image_w * np.sqrt(1 - self.probability)
        h = image_h * np.sqrt(1 - self.probability)
        x0 = int(np.round(max(cx - w / 2, 0)))
        x1 = int(np.round(min(cx + w / 2, image_w)))
        y0 = int(np.round(max(cy - h / 2, 0)))
        y1 = int(np.round(min(cy + h / 2, image_h)))

        ### 将遮挡物填充到原始图片
        data1[:, :, y0:y1, x0:x1] = shuffled_data1[:, :, y0:y1, x0:x1]
        data2[:, :, y0:y1, x0:x1] = shuffled_data2[:, :, y0:y1, x0:x1]

        return data1, data2, targets

class Mask_query(object) :
    def __init__(self, probability=0.0):
        """
        :param probability:表示未遮挡的部分占原图的面积比例
        """
        self.probability = probability

    def __call__(self, data1, data2, targets):

        if self.probability == 1.0 :
            return data1, data2, targets
        ### 随机选择遮挡物id
        indices = torch.randperm(data1.size(0))
        shuffled_data1 = data1[indices]
        shuffled_data2 = data2[indices]

        ### 随机选择图片中一部分
        image_h, image_w = data1.shape[2:]
        cx = np.random.uniform(0, image_w)
        cy = np.random.uniform(0, image_h)
        w = image_w * np.sqrt(1 - self.probability)
        h = image_h * np.sqrt(1 - self.probability)
        x0 = int(np.round(max(cx - w / 2, 0)))
        x1 = int(np.round(min(cx + w / 2, image_w)))
        y0 = int(np.round(max(cy - h / 2, 0)))
        y1 = int(np.round(min(cy + h / 2, image_h)))

        ### 将遮挡物填充到原始图片（填充方式1）
        # data1[:, :, y0:y1, x0:x1] = [0.485, 0.456, 0.406]
        # data2[:, :, y0:y1, x0:x1] = [0.485, 0.456, 0.406]
        ### 将遮挡物填充到原始图片（填充方式2）
        r,g,b = 0.485, 0.456, 0.406
        r,g,b = random.uniform(0,1), random.uniform(0,1), random.uniform(0,1)
        data1[:, 0, y0:y1, x0:x1] = r
        data1[:, 1, y0:y1, x0:x1] = g
        data1[:, 2, y0:y1, x0:x1] = b
        data2[:, 0, y0:y1, x0:x1] = r
        data2[:, 1, y0:y1, x0:x1] = g
        data2[:, 2, y0:y1, x0:x1] = b
        return data1, data2, targets