import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
import numpy as np
import torch
from torch.autograd import Variable

class Mixup_label(object) :
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def apply(self, inputs, labels):
        N = inputs.shape[0]
        lam = np.random.beta(self.alpha, self.alpha)
        while lam==0.5 :
            lam = np.random.beta(self.alpha, self.alpha)
        selected_class = torch.tensor(sorted(list(set(labels.cpu().numpy().tolist()))), dtype=torch.long)
        num_per_class = N // selected_class.shape[0]
        num_class = selected_class.shape[0]
        indices_labels = torch.randperm(selected_class.size()[0])      #### 3 2 1 0
        # print(indices_labels)
        ori_indices = torch.arange(0, N)
        indices = torch.arange(0, N)
        for i in range(num_class) :
            start_indice = indices_labels[i] * num_per_class
            end_indice = (indices_labels[i] + 1) * num_per_class
            permutation = torch.randperm(num_per_class)
            indices[i * num_per_class: (i+1) * num_per_class] = ori_indices[start_indice + permutation]
            # print(start_indice + permutation, num_per_class)

        out = inputs * lam + inputs[indices] * (1.0 - lam)
        # print(indices, indices_labels)

        return out, labels

if __name__ == "__main__" :
    data_size = 8
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = [0,0,1,1,2,2,3,3]
    targets = Variable(torch.IntTensor(y_))
    mixup = Mixup_label()
    print(mixup.apply(inputs, targets))
    print(y_, x)