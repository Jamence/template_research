import os, sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
import numpy as np
import torch

class Mixup(object) :
    def __init__(self, alpha=1.0):
        self.alpha = alpha
        self.lam = None
        self.indices = None

    def _update_lam(self):
        if self.alpha > 0.:
            self.lam = np.random.beta(self.alpha, self.alpha)
        else:
            self.lam = 1.

        return self.lam

    def apply_all(self, inputs, targets):
        if self.alpha > 0.:
            lam = np.random.beta(self.alpha, self.alpha)
        else:
            lam = 1.
        indices = torch.randperm(inputs.size(0))
        lam = torch.tensor(lam)
        lam = lam.repeat(inputs.size(0)).cuda()
        if len(inputs.size()) == 2 :
            lam = lam.view(-1, 1)
        elif len(inputs.size()) == 3 :
            lam = lam.view(-1, 1, 1)
        else :
            lam = lam.view(-1, 1, 1, 1)
        # print(indices.shape, lam.shape, (inputs * lam).shape)
        # print((1.0 - lam).shape)
        out = inputs * lam + inputs[indices] * (1.0 - lam)

        return inputs, out, lam, targets[indices]

    def apply(self, inputs):
        if self.alpha > 0.:
            lam = np.random.beta(self.alpha, self.alpha)
        else:
            lam = 1.
        self.indices = torch.randperm(inputs.size(0))
        out = inputs * lam + inputs[self.indices] * (1.0 - lam)
        return inputs, out, lam, self.indices