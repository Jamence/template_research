import numpy as np
import matplotlib.pyplot as plt
import torch
# import seaborn
# seaborn.set()

M = 2000
mean_1 = np.array([-5, -5])
conv_1 = np.array([[1, 0],[0, 1]])

torch_mean_1 = torch.tensor([5, 5], dtype=torch.float32)
torch_conv_1 = torch.tensor([1, 1], dtype=torch.float32)
torch_m_1 = torch.distributions.normal.Normal(torch_mean_1, torch_conv_1)
torch_sample_1 = torch_m_1.sample((1, M)).reshape(M, 2)
x_2, y_2 = torch_sample_1[:, 0].numpy(), torch_sample_1[:, 1].numpy()

# torch_mean_2 = torch.tensor([4, 4])
# torch_conv_2 = torch.tensor([[1, 1]])
# m2 = torch.distributions.normal.Normal(torch_mean_2, torch_conv_2)

x_1, y_1 = np.random.multivariate_normal(mean=mean_1, cov=conv_1, size=M).T

print(x_1, y_1)
print(x_2, y_2)

# x_2, y_2 = np.random.multivariate_normal(mean=mean_2, cov=conv_2, size=2000).T
# x_3, y_3 = np.random.multivariate_normal(mean=mean_3, cov=conv_3, size=2000).T
plt.plot(x_1, y_1, 'ro', alpha=0.05)
plt.plot(x_2, y_2, 'bo', alpha=0.05)
# plt.plot(x_3, y_3, 'g+', alpha=0.05)
plt.gca().axes.set_xlim(-10, 10)
plt.gca().axes.set_ylim(-10, 10)

plt.savefig("test.png")
plt.show()
