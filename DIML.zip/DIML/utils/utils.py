import torch
import random
import numpy as np

def binarize(T, nb_classes):
    T = T.cpu().numpy()
    import sklearn.preprocessing
    T = sklearn.preprocessing.label_binarize(
        T, classes = range(0, nb_classes)
    )
    T = torch.LongTensor(T).cuda()
    return T

def l2_norm(input):
    input_size = input.size()
    buffer = torch.pow(input, 2)
    normp = torch.sum(buffer, 1).add_(1e-12)
    norm = torch.sqrt(normp)
    _output = torch.div(input, norm.view(-1, 1).expand_as(input))
    output = _output.view(input_size)
    return output

def sample_lambdas(k) :
    """
    取样函数，从[0,1]中均匀取样k个样本数据
    :param k:
    :return:
    """
    result_list = {}
    if k == 1 :
        result_list[1] = 1.0
    else :
        random_k_num = []
        for index_k in range(1, k):
            random_k_num.append(np.random.uniform(0.0, 1.0))
        random_k_num.sort()

        previous_probability = 0.0
        for index_k in range(1, k):
            result_list[index_k] = random_k_num[index_k - 1] - previous_probability
            previous_probability = random_k_num[index_k - 1]
        result_list[k] = 1.0 - previous_probability
    return result_list

if __name__ == "__main__" :
    # T = torch.tensor([1,1,1,2,2,2])
    # nb_classes = 5
    # print(binarize(T, nb_classes))
    k = 4
    print(sample_lambdas(1))