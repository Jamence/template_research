import torch
import torch.nn as nn
import math
import torch.nn.functional as F
from torch.autograd import Variable
import numpy as np
import torch.nn.init as init
from torchvision.models import resnet18
from torchvision.models import resnet34
from torchvision.models import resnet50
from torchvision.models import resnet101
import torch.utils.model_zoo as model_zoo
from modules.mixup import Mixup
import random

class Resnet18(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        super(Resnet18, self).__init__()

        self.model = resnet18(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)

        avg_x = self.model.gap(x)
        max_x = self.model.gmp(x)

        x = max_x + avg_x
        
        x = x.view(x.size(0), -1)
        x = self.model.embedding(x)

        if self.is_norm:
            x = self.l2_norm(x)
            
        return x

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)

class Resnet34(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        super(Resnet34, self).__init__()

        self.model = resnet34(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)

        avg_x = self.model.gap(x)
        max_x = self.model.gmp(x)

        x = avg_x + max_x
        
        x = x.view(x.size(0), -1)
        x = self.model.embedding(x)

        if self.is_norm:
            x = self.l2_norm(x)

        return x

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)

class Resnet50(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        super(Resnet50, self).__init__()

        self.model = resnet50(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)

        avg_x = self.model.gap(x)
        max_x = self.model.gmp(x)

        x = max_x + avg_x
        x = x.view(x.size(0), -1)
        x = self.model.embedding(x)

        if self.is_norm:
            x = self.l2_norm(x)

        return x

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)

class Resnet50_aug(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        super(Resnet50_aug, self).__init__()
        print("using Resnet50_aug")

        self.model = resnet50(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x, y=None, mix_type = 'no', mix_layer = 5):
        """
        :param x:
        :param y:
        :param mix_type:     表示no、manifold-mixup
        :param mix_layer:    表示选择一个层进行mixup，
        :param mix_operator: 表示mixup类
        :return:
        """
        # 分为两条线，一条是正常的forward
        #           另一条是带有mixed的forward
        # print(x.shape, y.shape)
        if mix_type == 'manifold-mixup' :
            mix_layer = random.randint(0, 5)
        mixed_x, lam, rand_index = None, None, None
        # print(x.dtype)
        if mix_layer == 0 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            # print("mix_layer 0")
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        if mixed_x is not None:
            mixed_x = self.model.conv1(mixed_x)
            mixed_x = self.model.bn1(mixed_x)
            mixed_x = self.model.relu(mixed_x)
            mixed_x = self.model.maxpool(mixed_x)
            # print("using mixup 0")

        if mix_layer == 1 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            # print("mix_layer 1")
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
        # print(x.shape, type(x), mixed_x.shape, type(mixed_x))
        # print(x.dtype, mixed_x.dtype)
        x = self.model.layer1(x)
        if mixed_x is not None:
            mixed_x = self.model.layer1(mixed_x)
            # print("using mixup 1")

        if mix_layer == 2 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            # print("mix_layer 2")
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
        x = self.model.layer2(x)
        if mixed_x is not None:
            mixed_x = self.model.layer2(mixed_x)
            # print("using mixup 2")

        if mix_layer == 3 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            # print("mix_layer 3")
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
        x = self.model.layer3(x)
        if mixed_x is not None:
            mixed_x = self.model.layer3(mixed_x)
            # print("using mixup 3")

        if mix_layer == 4 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
            # print("mix_layer 4")
        x = self.model.layer4(x)
        if mixed_x is not None:
            mixed_x = self.model.layer4(mixed_x)
            # print("using mixup 4")

        avg_x = self.model.gap(x)
        max_x = self.model.gmp(x)
        x = max_x + avg_x
        x = x.view(x.size(0), -1)
        if mixed_x is not None:
            avg_mixed_x = self.model.gap(mixed_x)
            max_mixed_x = self.model.gmp(mixed_x)
            mixed_x = max_mixed_x + avg_mixed_x
            mixed_x = mixed_x.view(mixed_x.size(0), -1)
            # print("using mixup pooling")

        if mix_layer == 5 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
            mix_operater = Mixup()
            _, mixed_x, lam, shuffle_y = mix_operater.apply_all(x, y)
            # print("mixup 5")
        x = self.model.embedding(x)
        if mixed_x is not None:
            mixed_x = self.model.embedding(mixed_x)
            # print("using mixup 5")

        if self.training == False :
            return x

        return x, mixed_x, lam, shuffle_y

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)

class Resnet50_mix(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        """
        和Resent50_mix不同之处在于该模型只能得到一种类型的输出，例如origin， mixup， manifold-mixup
        :param embedding_size:
        :param pretrained:
        :param is_norm:
        :param bn_freeze:
        """
        super(Resnet50_mix, self).__init__()

        self.model = resnet50(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x, y=None, mix_type = 'no', mix_layer = None):
        """
        :param x:
        :param y:
        :param mix_type:     表示no、manifold-mixup
        :param mix_layer:    表示选择一个层进行mixup，
        :param mix_operator: 表示mixup类
        :return:
        """

        if mix_type == 'no' :
            x = self.model.conv1(x)
            x = self.model.bn1(x)
            x = self.model.relu(x)
            x = self.model.maxpool(x)
            x = self.model.layer1(x)
            x = self.model.layer2(x)
            x = self.model.layer3(x)
            x = self.model.layer4(x)

            avg_x = self.model.gap(x)
            max_x = self.model.gmp(x)

            x = max_x + avg_x
            x = x.view(x.size(0), -1)
            x = self.model.embedding(x)

            # if self.is_norm:
            #     x = self.l2_norm(x)

            return x
        else :
            lam, shuffle_y = None, None
            if mix_type == 'manifold-mixup' :
                if mix_layer < 0 :
                    mix_layer = random.randint(0, 2)

            if mix_layer == 0 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                # print(x.shape)
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)
                # print(x.shape)

            x = self.model.conv1(x)
            x = self.model.bn1(x)
            x = self.model.relu(x)
            x = self.model.maxpool(x)
            x = self.model.layer1(x)
            if mix_layer == 1 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)

            x = self.model.layer2(x)
            if mix_layer == 2 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)

            x = self.model.layer3(x)
            if mix_layer == 3 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)

            x = self.model.layer4(x)
            if mix_layer == 4 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)

            avg_x = self.model.gap(x)
            max_x = self.model.gmp(x)
            x = max_x + avg_x
            x = x.view(x.size(0), -1)
            x = self.model.embedding(x)
            if mix_layer == 5 and (mix_type == 'mixup' or mix_type == 'manifold-mixup'):
                mix_operater = Mixup()
                _, x, lam, shuffle_y = mix_operater.apply_all(x, y)

            return x, lam, shuffle_y

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)


class Resnet101(nn.Module):
    def __init__(self,embedding_size, pretrained=True, is_norm=True, bn_freeze = True):
        super(Resnet101, self).__init__()

        self.model = resnet101(pretrained)
        self.is_norm = is_norm
        self.embedding_size = embedding_size
        self.num_ftrs = self.model.fc.in_features
        self.model.gap = nn.AdaptiveAvgPool2d(1)
        self.model.gmp = nn.AdaptiveMaxPool2d(1)

        self.model.embedding = nn.Linear(self.num_ftrs, self.embedding_size)
        self._initialize_weights()

        if bn_freeze:
            for m in self.model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()
                    m.weight.requires_grad_(False)
                    m.bias.requires_grad_(False)

    def l2_norm(self,input):
        input_size = input.size()
        buffer = torch.pow(input, 2)

        normp = torch.sum(buffer, 1).add_(1e-12)
        norm = torch.sqrt(normp)

        _output = torch.div(input, norm.view(-1, 1).expand_as(input))

        output = _output.view(input_size)

        return output

    def forward(self, x):
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        x = self.model.layer2(x)
        x = self.model.layer3(x)
        x = self.model.layer4(x)

        avg_x = self.model.gap(x)
        max_x = self.model.gmp(x)

        x = max_x + avg_x
        x = x.view(x.size(0), -1)
        x = self.model.embedding(x)
        
        if self.is_norm:
            x = self.l2_norm(x)
            
        return x

    def _initialize_weights(self):
        init.kaiming_normal_(self.model.embedding.weight, mode='fan_out')
        init.constant_(self.model.embedding.bias, 0)