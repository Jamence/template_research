'''
实现ProxyAnchor
@author:  Jamence
@contact: jamence@163.com
'''
import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.utils import l2_norm, binarize


class MixedProxyAnchor(torch.nn.Module):
    def __init__(self, nb_classes, sz_embed, mrg=0.1, alpha=32, omega1=0.2, omega2 = 0.2):
        torch.nn.Module.__init__(self)
        # Proxy Anchor Initialization
        self.proxies = torch.nn.Parameter(torch.randn(nb_classes, sz_embed).cuda())
        nn.init.kaiming_normal_(self.proxies, mode='fan_out')

        self.nb_classes = nb_classes
        self.sz_embed = sz_embed
        self.mrg = mrg
        self.alpha = alpha
        self.omega1 = omega1
        self.omega2 = omega2

    def get_ori_loss(self, X, P, T, nb_classes):

        cos = F.linear(l2_norm(X), l2_norm(P))  # Calcluate cosine similarity
        # print("cos is ", cos)
        P_one_hot = binarize(T=T, nb_classes=nb_classes)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        # print(P_one_hot.shape, pos_exp.shape)
        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / self.nb_classes
        loss = pos_term + neg_term
        return loss

    def get_mixed_loss(self, X, T, MixedX, lam, shuffleT):
        P = self.proxies

        MixedP = lam.view(-1, 1) * P[T] + (1 - lam.view(-1, 1)) * P[shuffleT]  # C * D
        AllP = torch.cat((P, MixedP), dim=0)  # 2C * D

        targetT = torch.arange(self.nb_classes, self.nb_classes + X.shape[0]).cuda()
        mixed_loss = self.get_ori_loss(MixedX, AllP, targetT, self.nb_classes + X.shape[0])
        return mixed_loss

    def get_mixed_loss_(self, X, T, MixedX, lam, shuffleT):
        """
        表示在loss计算过程中省略掉原始anchor
        :param X:
        :param T:
        :param MixedX:
        :param lam:
        :param indices:
        :return:
        """
        P = self.proxies
        N = X.size(0)
        C = P.size(0)
        D = X.size(1)

        mixed_P = lam.view(-1, 1) * P[T] + (1 - lam.view(-1, 1)) * P[shuffleT]  # N * D

        ### 不计算同类logits
        dist_mixedX2P = F.normalize(MixedX, p=2, dim=1).matmul(F.normalize(P, p=2, dim=1).t())  # N * C
        onehot1 = torch.zeros(N, C).cuda()
        onehot1.scatter_(1, T.view(-1, 1), 1)
        onehot2 = torch.zeros(N, C).cuda()
        onehot2.scatter_(1, shuffleT.view(-1, 1), 1)
        onehot = 1 - (1 - onehot1) * (1 - onehot2)        #  0 0 0  0 1 1  1 0 1  1 1 1
        dist_mixedX2P = torch.where(onehot == 0, dist_mixedX2P, torch.zeros_like(dist_mixedX2P))  # N * C

        ### 添加mixed logits
        dist_mixedX2mixedP = F.normalize(MixedX, p=2, dim=1).matmul(F.normalize(mixed_P, p=2, dim=1).t())  # N * N
        dist_mixedX2mixedP_diag = dist_mixedX2mixedP.diag().unsqueeze(1)  # N * 1

        sim_mat = torch.cat((dist_mixedX2mixedP_diag, dist_mixedX2P), dim=-1)  # N * (C + 1)
        cos = sim_mat
        targetT = torch.zeros(N, dtype=torch.long).cuda()
        P_one_hot = binarize(T=targetT, nb_classes=C + 1)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        # print(P_one_hot.shape, pos_exp.shape)
        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / (C + 1)
        loss = pos_term + neg_term
        return loss

    def forward(self, X, T, MixedX=None, lam=None, shuffleT=None):
        """
        :param X:        原始样本特征
        :param T:        原始样本标签
        :param MixedX:   混合样本特征
        :param lam:      混合比例
        :param indices:  打乱的序号
        :return:
        """
        ori_loss = self.get_ori_loss(X, self.proxies, T, self.nb_classes)
        if MixedX is None :
            return ori_loss
        mixed_loss = self.get_mixed_loss(X, T, MixedX, lam, shuffleT)
        return self.omega1 * ori_loss + self.omega2 * mixed_loss