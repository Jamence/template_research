from __future__ import absolute_import
import torch
from torch import nn
from torch.autograd import Variable
import numpy as np
from modules.mixup import Mixup
from utils.utils import l2_norm

def similarity(inputs_):
    # Compute similarity mat of deep feature
    # n = inputs_.size(0)
    sim = torch.matmul(inputs_, inputs_.t())
    return sim

class MixedTripletHard(nn.Module):
    def __init__(self, beta=None, margin=0.01, omega1 = 0.2 ,**kwargs):
        super(MixedTripletHard, self).__init__()
        self.beta = beta
        self.margin = margin
        self.omega1 = omega1

    def get_ori_loss(self, inputs, targets):
        n = inputs.size(0)
        sim_mat = torch.matmul(l2_norm(inputs), l2_norm(inputs).t())
        targets = targets
        ori_loss = list()
        c = 0
        for i in range(n):
            pos_pair_ = torch.masked_select(sim_mat[i], targets == targets[i])
            #  move itself
            pos_pair_ = torch.masked_select(pos_pair_, pos_pair_ < 1)
            neg_pair_ = torch.masked_select(sim_mat[i], targets != targets[i])
            pos_pair_ = torch.sort(pos_pair_)[0]
            neg_pair_ = torch.sort(neg_pair_)[0]
            neg_pair = torch.masked_select(neg_pair_, neg_pair_ > pos_pair_[0] - self.margin)
            pos_pair = torch.masked_select(pos_pair_, pos_pair_ < neg_pair_[-1] + self.margin)
            # pos_pair = pos_pair[1:]
            if len(neg_pair) < 1:
                c += 1
                continue
            pos_loss = torch.mean(1 - pos_pair)
            neg_loss = torch.mean(neg_pair)
            # pos_loss = torch.mean(torch.log(1 + torch.exp(-2*(pos_pair - self.margin))))
            # neg_loss = 0.04*torch.mean(torch.log(1 + torch.exp(50*(neg_pair - self.margin))))
            ori_loss.append(pos_loss + neg_loss)
        ori_loss = sum(ori_loss) / n
        return ori_loss

    def get_mixed_loss(self, X, T, MixedX, lam, indices):
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(X)))
        c = 0
        targets = T
        n = X.size(0)
        mixed_loss = list()
        for i in range(n):
            pos_pair_1 = torch.masked_select(sim_mat[i], targets == targets[i])
            pos_pair_2 = torch.masked_select(sim_mat[i], targets == targets[indices][i])

            neg_pair_ = torch.masked_select(sim_mat[i], (targets != targets[i]) & (targets != targets[indices][i]))
            P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
            pos_pair_ = lam * pos_pair_1.view(P1, 1) + (1 - lam) * pos_pair_2.view(1, P2)
            pos_pair_ = pos_pair_.flatten()
            pos_pair_ = torch.sort(pos_pair_)[0]
            neg_pair_ = torch.sort(neg_pair_)[0]
            # print(pos_pair_.shape, neg_pair_.shape)
            neg_pair = torch.masked_select(neg_pair_, neg_pair_ > pos_pair_[0] - self.margin)
            pos_pair = torch.masked_select(pos_pair_, pos_pair_ < neg_pair_[-1] + self.margin)
            # pos_pair = pos_pair[1:]
            if len(neg_pair) < 1:
                c += 1
                continue
            pos_loss = torch.mean(1 - pos_pair)
            neg_loss = torch.mean(neg_pair)

            mixed_loss.append(pos_loss + neg_loss)
        mixed_loss = sum(mixed_loss) / n
        return mixed_loss

    def forward(self, X, T, MixedX=None, lam=None, indices=None):
        ori_loss = self.get_ori_loss(X, T)
        if MixedX is None:
            return ori_loss
        mixed_loss = self.get_mixed_loss(X, T, MixedX, lam, indices)

        return ori_loss + self.omega1 * mixed_loss

def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8*list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    print(MixedTripletHard()(inputs, targets))
if __name__ == '__main__':
    main()
    print('Congratulations to you!')
