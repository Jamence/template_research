# Copyright (c) Malong Technologies Co., Ltd.
# All rights reserved.
#
# Contact: github@malong.com
#
# This source code is licensed under the LICENSE file in the root directory of this source tree.

import torch
from torch import nn
from modules.mixup import Mixup
from torch.autograd import Variable
from utils.utils import l2_norm, binarize


class MixedMultiSimilarityLoss(nn.Module):
    def __init__(self, scale_pos=2.0, scale_neg=50.0, omega1 = 0.2, omega2 = 0.2):
        super(MixedMultiSimilarityLoss, self).__init__()
        self.thresh = 0.5
        self.margin = 0.1

        self.scale_pos = scale_pos
        self.scale_neg = scale_neg
        self.omega1 = omega1
        self.omega2 = omega2

    def get_ori_loss(self, feats, labels):
        assert feats.size(0) == labels.size(0), \
            f"feats.size(0): {feats.size(0)} is not equal to labels.size(0): {labels.size(0)}"
        batch_size = feats.size(0)
        sim_mat = torch.matmul(l2_norm(feats), torch.t(l2_norm(feats)))

        epsilon = 1e-5
        ori_loss = list()

        for i in range(batch_size):
            pos_pair_ = sim_mat[i][labels == labels[i]]
            pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
            neg_pair_ = sim_mat[i][labels != labels[i]]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
            pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]

            if len(neg_pair) < 1 or len(pos_pair) < 1:
                continue
            # print("ori pair : ", pos_pair_.mean(), neg_pair_.mean())
            # weighting step
            pos_loss = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))
            # print("ori loss : ", pos_loss, neg_loss)
            ori_loss.append(pos_loss + neg_loss)

        # if len(ori_loss) == 0:
        #     return torch.zeros([], requires_grad=True)

        ori_loss = sum(ori_loss) / batch_size
        return ori_loss

    def get_mixed_loss(self, X, T, MixedX, lam, shuffleT):
        mixed_loss = list()
        labels = T
        batch_size = X.size(0)
        epsilon = 1e-5
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(X)))
        for i in range(batch_size):
            ### pos1
            pos_pair_1 = sim_mat[i][labels == labels[i]]
            pos_pair_2 = sim_mat[i][labels == shuffleT[i]]
            P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
            pos_pair_ = (lam[i].item() * pos_pair_1.view(P1, 1) + (1 - lam[i].item()) * pos_pair_2.view(1, P2)).reshape(
                P1 * P2, -1).squeeze()

            pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
            pos_pair_, _ = pos_pair_.topk(max(P1, P2), dim=0, largest=False)

            neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == shuffleT[i]))]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
            pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]
            # print("mixed pair : ", pos_pair_.mean(), neg_pair_.mean())

            if len(neg_pair) < 1 or len(pos_pair) < 1:
                continue

            # weighting step
            pos_loss = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))

            mixed_loss.append(pos_loss + neg_loss)

        mixed_loss = sum(mixed_loss) / batch_size

        return mixed_loss

    def get_mixed_loss_theta(self, X, T, MixedX, lam, shuffleT):
        mixed_loss = list()
        labels = T
        batch_size = X.size(0)
        epsilon = 1e-5
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(X)))
        for i in range(batch_size):
            ### pos1
            pos_pair_1 = sim_mat[i][labels == labels[i]]
            pos_pair_2 = sim_mat[i][labels == shuffleT[i]]

            pos_pair_1_theta = torch.acos(pos_pair_1)
            pos_pair_2_theta = torch.acos(pos_pair_2)

            P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
            # pos_pair_ = (lam[i].item() * pos_pair_1.view(P1, 1) + (1 - lam[i].item()) * pos_pair_2.view(1, P2)).reshape(P1*P2, -1).squeeze()
            pos_pair_ = torch.cos(lam[i].item() * pos_pair_1_theta.view(P1, 1) + (1 - lam[i].item()) * pos_pair_2_theta.view(1, P2))

            pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
            pos_pair_, _ = pos_pair_.topk(max(P1, P2), dim=0, largest=False)

            neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == shuffleT[i]))]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
            pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]
            # print("mixed pair : ", pos_pair_.mean(), neg_pair_.mean())

            if len(neg_pair) < 1 or len(pos_pair) < 1:
                continue

            # weighting step
            pos_loss = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))

            mixed_loss.append(pos_loss + neg_loss)

        mixed_loss = sum(mixed_loss) / batch_size

        return mixed_loss

    def get_mixed_loss_suitable(self, X, T, MixedX, lam, shuffleT):
        mixed_loss = list()
        labels = T
        batch_size = X.size(0)
        epsilon = 1e-5
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(X)))
        for i in range(batch_size):
            ### pos1
            if labels[i] == shuffleT[i] :
                pos_pair_ = sim_mat[i][labels == labels[i]]
                pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
            else :
                pos_pair_1 = sim_mat[i][labels == labels[i]]
                pos_pair_2 = sim_mat[i][labels == shuffleT[i]]
                P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
                pos_pair_ = (lam[i].item() * pos_pair_1.view(P1, 1) + (1 - lam[i].item()) * pos_pair_2.view(1, P2)).reshape(
                    P1 * P2, -1).flatten()
                pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
                # pos_pair_, _ = torch.topk(pos_pair_, k=, largest=False)
            neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == shuffleT[i]))]
            # print("------------------------------------")
            # print(labels == labels[i])
            # print(labels == labels[indices][i])
            # print(~((labels == labels[i]) | (labels == labels[indices][i])))
            # print("====================================")

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
            pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]
            # print("mixed pair : ", pos_pair_.mean(), neg_pair_.mean())

            if len(neg_pair) < 1 or len(pos_pair) < 1:
                continue

            # weighting step
            pos_loss = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))

            mixed_loss.append(pos_loss + neg_loss)

        mixed_loss = sum(mixed_loss) / batch_size

        return mixed_loss

    def get_mixed_loss_suitable_1(self, X, T, MixedX, lam, shuffleT):
        mixed_loss = list()
        labels = T
        batch_size = X.size(0)
        epsilon = 1e-5
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(X)))
        for i in range(batch_size):

            pos_pair_1 = sim_mat[i][labels == labels[i]]
            pos_pair_1 = pos_pair_1[pos_pair_1 < 1 - epsilon]

            pos_pair_2 = sim_mat[i][labels == shuffleT[i]]
            pos_pair_2 = pos_pair_2[pos_pair_2 < 1 - epsilon]

            neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == shuffleT[i]))]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_1)]
            neg_pair = neg_pair[neg_pair + self.margin > min(pos_pair_2)]
            pos_pair_1 = pos_pair_1[pos_pair_1 - self.margin < max(neg_pair_)]
            pos_pair_2 = pos_pair_2[pos_pair_2 - self.margin < max(neg_pair_)]

            if len(neg_pair) < 1 or len(pos_pair_1) < 1 or len(pos_pair_2) < 1 :
                continue

            # weighting step
            pos_loss_1 = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair_1 - self.thresh))))
            pos_loss_2 = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair_2 - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))
            mixed_loss.append(lam * pos_loss_1 + (1 - lam) * pos_loss_2 + neg_loss)

        mixed_loss = sum(mixed_loss) / batch_size

        return mixed_loss

    def forward(self, X, T, MixedX=None, lam=None, shuffleT=None):
        ori_loss = self.get_ori_loss(X, T)
        if MixedX is None:
            return ori_loss
        # mixed_loss = self.get_mixed_loss(X, T, MixedX, lam, shuffleT)
        mixed_loss = self.get_mixed_loss_suitable(X, T, MixedX, lam, shuffleT)

        return self.omega1 * ori_loss + self.omega2 * mixed_loss

def main():
    data_size = 32
    input_dim = 256
    output_dim = 256
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8 * list(range(num_class))
    targets = Variable(torch.IntTensor(y_))

    print(MixedMultiSimilarityLoss()(inputs, targets))

if __name__ == "__main__" :
    main()