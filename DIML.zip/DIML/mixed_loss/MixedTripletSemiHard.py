### 添加 欧氏距离
from __future__ import absolute_import
import torch
from torch import nn
from torch.autograd import Variable
import numpy as np
from modules.mixup import Mixup
from utils.utils import l2_norm

class MixedTripletSemiHard(nn.Module):
    def __init__(self, beta=None, margin=0.1, omega1 = 0.2, **kwargs):
        super(MixedTripletSemiHard, self).__init__()
        self.beta = beta
        self.margin = margin
        self.omega1 = omega1

    def triplet_distance(self, anchor, positive, negative):
        return torch.nn.functional.relu(
            (anchor - positive).pow(2).sum() - (anchor - negative).pow(2).sum() + self.margin)

    def mixed_triplet_distance(self, anchor, positive1, positive2, negative, lam):
        dp1 = (anchor - positive1).pow(2).sum()
        dp2 = (anchor - positive2).pow(2).sum()
        dn = (anchor - negative).pow(2).sum()
        return torch.nn.functional.relu(lam * dp1 + (1 - lam) * dp2 - dn + self.margin)

    def pdist(self, A):
        prod = torch.mm(A, A.t())
        norm = prod.diag().unsqueeze(1).expand_as(prod)
        res = (norm + norm.t() - 2 * prod).clamp(min=0)
        return res.clamp(min=0).sqrt()

    def euclidean_dist(self, x, y):
        """
        Args:
          x: pytorch Variable, with shape [m, d]
          y: pytorch Variable, with shape [n, d]
        Returns:
          dist: pytorch Variable, with shape [m, n]
        """
        m, n = x.size(0), y.size(0)
        xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
        yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
        dist = xx + yy
        dist.addmm_(1, -2, x, y.t())
        dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability
        return dist

    def get_ori_loss(self, X, T):
        inputs = X
        targets = T
        n = inputs.size(0)
        inputs = l2_norm(inputs)

        ### 取样
        distances = self.euclidean_dist((inputs).detach(), (inputs).detach()).detach().cpu().numpy()
        targets = targets.cpu().numpy()
        positives, negatives, anchors = [], [], []

        for i in range(n):
            l, d = targets[i], distances[i]
            neg = targets != l;
            pos = targets == l

            anchors.append(i)
            pos[i] = 0
            p = np.random.choice(np.where(pos)[0])
            positives.append(p)

            # Find negatives that violate tripet constraint semi-negatives
            neg_mask = np.logical_and(neg, d > d[p])
            neg_mask = np.logical_and(neg_mask, d < self.margin + d[p])
            if neg_mask.sum() > 0:
                negatives.append(np.random.choice(np.where(neg_mask)[0]))
            else:
                negatives.append(np.random.choice(np.where(neg)[0]))
        sampled_triplets = [[a, p, n] for a, p, n in zip(anchors, positives, negatives)]

        ## 计算loss
        loss = torch.stack(
            [self.triplet_distance(inputs[triplet[0], :], inputs[triplet[1], :], inputs[triplet[2], :]) for triplet in
             sampled_triplets])
        # print("haha")
        ori_loss = torch.mean(loss)
        return ori_loss

    def get_mixed_loss(self, X, T, MixedX, lam, indices):
        n = X.size(0)
        targets = T
        X, MixedX = l2_norm(X), l2_norm(MixedX)

        distances = self.euclidean_dist(MixedX.detach(), X.detach()).detach().cpu().numpy()
        targets1 = targets
        targets2 = targets[indices]
        positives1, positives2, negatives, anchors = [], [], [], []

        for i in range(n):
            l1, l2, d = targets1[i], targets2[i], distances[i]
            neg = (targets != l1) & (targets != l2)
            pos1 = targets == l1
            pos2 = targets == l2

            anchors.append(i)
            pos1[i], pos2[i] = 0, 0
            p1 = np.random.choice(np.where(pos1)[0])
            p2 = np.random.choice(np.where(pos2)[0])
            positives1.append(p1)
            positives2.append(p2)

            # Find negatives that violate tripet constraint semi-negatives
            neg_mask = np.logical_and(neg, d > (lam * d[p1] + (1 - lam) * d[p2]))
            neg_mask = np.logical_and(neg_mask, d < self.margin + (lam * d[p1] + (1 - lam) * d[p2]))
            if neg_mask.sum() > 0:
                negatives.append(np.random.choice(np.where(neg_mask)[0]))
            else:
                negatives.append(np.random.choice(np.where(neg)[0]))
        sampled_triplets = [[a, p1, p2, n] for a, p1, p2, n in zip(anchors, positives1, positives2, negatives)]

        ## 计算loss
        loss = torch.stack(
            [self.mixed_triplet_distance(MixedX[triplet[0], :], X[triplet[1], :], X[triplet[2], :],
                                         X[triplet[3], :], lam) for triplet in
             sampled_triplets])
        # print("haha")
        mixed_loss = torch.mean(loss)
        return mixed_loss

    def forward(self, X, T, MixedX=None, lam=None, indices=None):
        ori_loss = self.get_ori_loss(X, T)
        if MixedX is None:
            return ori_loss
        mixed_loss = self.get_mixed_loss(X, T, MixedX, lam, indices)

        return ori_loss + self.omega1 * mixed_loss

def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8*list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    print(MixedTripletSemiHard()(inputs, targets))
if __name__ == '__main__':
    main()
    print('Congratulations to you!')
