#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=1e-4
DATASET=cub
WARM=1
BN_FREEZE=1
LR_DECAY_STEP=10

echo "Start Training"
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP}