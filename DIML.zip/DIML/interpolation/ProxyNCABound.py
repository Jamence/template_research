'''
实现非loss函数层面的特征插值
@author:  Jamence
@contact: jamence@163.com
'''
import torch
from torch.nn import Parameter
import torch.nn.functional as F
from loss.EstimatorCV import EstimatorCV


def binarize_and_smooth_labels(T, nb_classes, smoothing_const=0.1):
    # Optional: BNInception uses label smoothing, apply it for retraining also
    # "Rethinking the Inception Architecture for Computer Vision", p. 6
    import sklearn.preprocessing
    T = T.cpu().numpy()
    T = sklearn.preprocessing.label_binarize(
        T, classes=range(0, nb_classes)
    )
    T = T * (1 - smoothing_const)
    T[T == 0] = smoothing_const / (nb_classes - 1)
    T = torch.FloatTensor(T).cuda()
    return T

class ProxyNCABound(torch.nn.Module):
    def __init__(self,
                 nb_classes,
                 sz_embedding,
                 smoothing_const=0.1,
                 scaling_x=1,
                 scaling_p=3
                 ):
        torch.nn.Module.__init__(self)
        # initialize proxies s.t. norm of each proxy ~1 through div by 8
        # i.e. proxies.norm(2, dim=1)) should be close to [1,1,...,1]
        # TODO: use norm instead of div 8, because of embedding size
        self.proxies = Parameter(torch.randn(nb_classes, sz_embedding) / 8)
        self.smoothing_const = smoothing_const
        self.scaling_x = scaling_x
        self.scaling_p = scaling_p
        self.estimator = EstimatorCV(sz_embedding, nb_classes)

    def forward(self, X, T):
        """
        :param X:  原始输入特征
        :param T:  原始输入标签
        :return:
        """
        P = F.normalize(self.proxies, p=2, dim=-1) * self.scaling_p  ###   C * D
        X = F.normalize(X, p=2, dim=-1) * self.scaling_x             ###   N * D
        self.estimator.update_CV(X.detach(), T)

        T_ = binarize_and_smooth_labels(T, len(P), self.smoothing_const)         ### N * C
        C, N, D = self.proxies.shape[0], X.shape[0], self.proxies.shape[1]

        Dist = 2 * F.linear(X, P)
        p_z = self.proxies
        p_y = self.proxies[T]

        coVariance = self.estimator.CoVariance[T]
        term_bound = (2 * (p_z.view(1, C, D) - p_y.view(N, 1, D))).pow(2).mul(
            coVariance.view(N, 1, D).expand(N, C, D)
        ).sum(2)
        loss = torch.sum(-T_ * F.log_softmax(Dist + 0.5 * term_bound, -1), -1)  ### N * C
        # # print(loss, loss.mean())
        #
        # #------------------------------------------------------
        # ## 类似于ISDA的实现
        # p_z = self.proxies.expand(N, C, D)
        # p_y = torch.gather(p_z, 1, T.view(N, 1, 1).expand(N, C, D))
        # print(p_y)
        # sigma2 = (2 * (p_z - p_y)).pow(2).mul(coVariance.view(N, 1, D).expand(N, C, D)).sum(2)
        # print(term_bound, sigma2)
        return loss.mean()


if __name__ == '__main__':
    import random

    nb_classes = 5
    sz_batch = 2
    sz_embedding = 2
    X = torch.randn(sz_batch, sz_embedding).cuda()
    P = torch.randn(nb_classes, sz_embedding).cuda()
    T = torch.randint(low=0, high=nb_classes, size=[sz_batch]).cuda()
    criterion = ProxyNCABound(nb_classes, sz_embedding).cuda()

    print(criterion(X, T.view(sz_batch)))