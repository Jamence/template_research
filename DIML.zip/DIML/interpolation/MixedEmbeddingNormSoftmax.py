'''
实现MixedEmbeddingNormSoftmax
@author:  Jamence
@contact: jamence@163.com
'''

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from torch.nn.parameter import Parameter
from utils.EstimatorCV import EstimatorCV
from modules.mixup import Mixup

class MixedEmbeddingNormSoftmax(nn.Module):
    def __init__(self, input_dim, n_classes, temperature=0.05, omega1 = 0.2):
        super(MixedEmbeddingNormSoftmax, self).__init__()
        self.n_classes = n_classes
        self.proxy = Parameter(torch.Tensor(n_classes, input_dim))

        stdv = 1. / math.sqrt(self.proxy.size(1))
        self.proxy.data.uniform_(-stdv, stdv)
        self.temperature = temperature
        self.estimator = EstimatorCV(input_dim, n_classes)
        self.omega1 = omega1

    def calculate_loss(self, X, P, T, CoVariance, weight=1.0):
        C, N, D = self.proxy.shape[0], X.shape[0], self.proxy.shape[1]
        sim_mat = X.matmul(P.t())
        p_z = self.proxy
        p_y = self.proxy[T]
        logits = sim_mat / self.temperature + weight * ((0.5 / (self.temperature * self.temperature)) * (p_z.view(1, C, D) - p_y.view(N, 1, D))).pow(2).mul(
            CoVariance.view(N, 1, D).expand(N, C, D)
        ).sum(2)
        return F.cross_entropy(logits, T)

    def get_oriloss(self, input, target):
        input_l2 = F.normalize(input, p=2, dim=1)
        proxy_l2 = F.normalize(self.proxy, p=2, dim=1)

        sim_mat = input_l2.matmul(proxy_l2.t())

        logits = sim_mat / self.temperature

        loss = F.cross_entropy(logits, target)

        return loss

    def forward(self, X, T):

        X = F.normalize(X, p=2, dim=1)
        P = F.normalize(self.proxy, p=2, dim=1)
        self.estimator.update_CV(X.detach(), T)
        normSoftmax_loss = self.calculate_loss(X, P, T, self.estimator.CoVariance[T], weight=0.0)

        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(X)
        shuffledT = T[indices]
        MixedCoVariance = lam * lam * self.estimator.CoVariance[T] + (1 - lam) * (1 - lam) * self.estimator.CoVariance[
            shuffledT]
        mixed_loss = lam * self.calculate_loss(MixedX, P, T, MixedCoVariance) + (1 - lam) * self.calculate_loss(MixedX,
                                                                                                                P,
                                                                                                                        shuffledT,
                                                                                                                MixedCoVariance)
        return normSoftmax_loss + self.omega1 * mixed_loss
if __name__ == '__main__':
    import random

    nb_classes = 100
    sz_batch = 4
    sz_embedding = 4
    X = torch.randn(sz_batch, sz_embedding).cuda()
    P = torch.randn(nb_classes, sz_embedding).cuda()
    T = torch.randint(low=0, high=nb_classes, size=[sz_batch]).cuda()
    criterion = MixedEmbeddingNormSoftmax(sz_embedding,nb_classes ).cuda()

    print(criterion(X, T.view(sz_batch)))