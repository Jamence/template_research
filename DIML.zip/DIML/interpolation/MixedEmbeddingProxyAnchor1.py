'''
实现embdding层面的特征插值——ProxyAnchor (将anchor插值，生成新类别)
@author:  Jamence
@contact: jamence@163.com
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.utils import l2_norm, binarize, sample_lambdas
from torch.autograd import Variable

class MixedEmbeddingProxyAnchor(torch.nn.Module):
    def __init__(self, nb_classes, sz_embed, mrg=0.1, alpha=32, omega1=0.2):
        torch.nn.Module.__init__(self)
        # Proxy Anchor Initialization
        self.proxies = torch.nn.Parameter(torch.randn(nb_classes, sz_embed).cuda())
        nn.init.kaiming_normal_(self.proxies, mode='fan_out')

        self.nb_classes = nb_classes
        self.sz_embed = sz_embed
        self.mrg = mrg
        self.alpha = alpha
        self.omega1 = omega1

    def forward(self, X, T):
        ################# 得到新的anchor
        P = self.proxies
        selected_anchor = torch.tensor(sorted(list(set(T.cpu().numpy().tolist()))), dtype=torch.long)
        len_selected_anchor = selected_anchor.shape[0]

        k = 2
        indices = {}

        P_one_hot_set = {}
        ori_positive = binarize(T=T, nb_classes=self.nb_classes).transpose(0, 1)    ### C * N  X的张量大小为N * D

        for index_k in range(1, k + 1):
            ori_indices = torch.arange(0, self.nb_classes)
            if index_k == 1:
                temp_index = torch.arange(0, len_selected_anchor).cuda()
                ori_indices[selected_anchor] = selected_anchor[temp_index]
                indices[index_k] = ori_indices
                P_one_hot_set[index_k] = ori_positive[ori_indices]
            else:
                temp_index = torch.randperm(len_selected_anchor).cuda()
                ori_indices[selected_anchor] = selected_anchor[temp_index]
                indices[index_k] = ori_indices
                P_one_hot_set[index_k] = ori_positive[ori_indices]

        ### 得到比值
        lambdas = sample_lambdas(k)

        ### anchor的混合
        Mixed_P = None
        for i in range(1, k + 1):
            if Mixed_P is None:
                Mixed_P = P[indices[i]] * lambdas[i]
            else:
                Mixed_P = Mixed_P + P[indices[i]] * lambdas[i]

        ################# 距离余弦计算
        cos_temp = F.linear(l2_norm(Mixed_P), l2_norm(X))  ### C * N

        ################# 得到正样本,以及正样本距离
        # mixed_anchor到第一个positive set的距离   M * T  (T表示一个类包含的样本数量)
        dis_anchor2positive1 = cos_temp[P_one_hot_set[1] == 1].reshape(len_selected_anchor, -1)
        dis_anchor2positive1_exp_sum = torch.log(torch.exp(-self.alpha * (dis_anchor2positive1 - self.mrg)).sum(dim=1))  ### M * 1
        # mixed_anchor到第一个positive set的距离   M * T  (T表示一个类包含的样本数量)
        dis_anchor2positive2 = cos_temp[P_one_hot_set[2] == 1].reshape(len_selected_anchor, -1)
        dis_anchor2positive2_exp_sum = torch.log(torch.exp(-self.alpha * (dis_anchor2positive2 - self.mrg)).sum(dim=1))  ### M * 1
        dis_anchor2positive_exp_sum = lambdas[1] * dis_anchor2positive1_exp_sum + lambdas[2] * dis_anchor2positive2_exp_sum
        pos_term = dis_anchor2positive_exp_sum.sum() / len_selected_anchor

        # print(dis_anchor2positive1.shape, dis_anchor2positive2.shape)
        # dis_anchor2positive = dis_anchor2positive1.reshape(len_selected_anchor, 1, -1) + dis_anchor2positive2.reshape(len_selected_anchor, -1, 1)
        # dis_anchor2positive = dis_anchor2positive.reshape(len_selected_anchor, -1)
        # pos_exp = torch.exp(-self.alpha * (dis_anchor2positive - self.mrg)).sum(dim=1)
        # pos_term = torch.log(1 + pos_exp).sum() / len_selected_anchor

        ################# 得到负样本，以及负样本距离
        P_one_hot_orset = None
        for index_k in range(1, k + 1):
            if index_k == 1:
                P_one_hot_orset = P_one_hot_set[index_k]
            else:
                P_one_hot_orset = P_one_hot_orset | P_one_hot_set[index_k]
        N_one_hot = 1 - P_one_hot_orset                            ### C * N
        neg_exp = torch.exp(self.alpha * (cos_temp + self.mrg))
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(cos_temp)).sum(dim=1)
        neg_term = torch.log(1+N_sim_sum).sum() / self.nb_classes

        # print(pos_term, neg_term)
        loss = pos_term + neg_term

        ########################## ori
        # print("proxy is ", self.proxies)
        P = self.proxies

        cos = F.linear(l2_norm(X), l2_norm(P))  # Calcluate cosine similarity
        # print("cos is ", cos)
        P_one_hot = binarize(T=T, nb_classes=self.nb_classes)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / self.nb_classes
        loss_ori = pos_term + neg_term

        return self.omega1 * loss + loss_ori

if __name__ == "__main__" :
    data_size = 32
    input_dim = 256
    output_dim = 512
    num_class = 8
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 4 * list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    # print(inputs.shape, targets.shape, targets)

    inputs = inputs.cuda()
    targets = targets.cuda()

    # print(Mixed_Proxy_Anchor4(nb_classes=16, sz_embed=512)(inputs, targets))
    # print(Proxy_Anchor(nb_classes=16, sz_embed=512)(inputs, targets))
