'''
实现embdding层面的特征插值——NormSoftmax
@author:  Jamence
@contact: jamence@163.com
'''
