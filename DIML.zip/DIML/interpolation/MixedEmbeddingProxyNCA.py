'''
实现embdding层面的特征插值——ProxyNCA
@author:  Jamence
@contact: jamence@163.com
'''
import torch
from torch.nn import Parameter
import torch.nn.functional as F
from utils.EstimatorCV import EstimatorCV
from modules.mixup import Mixup

def binarize_and_smooth_labels(T, nb_classes, smoothing_const=0.1):
    # Optional: BNInception uses label smoothing, apply it for retraining also
    # "Rethinking the Inception Architecture for Computer Vision", p. 6
    import sklearn.preprocessing
    T = T.cpu().numpy()
    T = sklearn.preprocessing.label_binarize(
        T, classes=range(0, nb_classes)
    )
    T = T * (1 - smoothing_const)
    T[T == 0] = smoothing_const / (nb_classes - 1)
    T = torch.FloatTensor(T).cuda()
    return T

class MixedEmbeddingProxyNCA(torch.nn.Module):
    def __init__(self,
                 nb_classes,
                 sz_embedding,
                 smoothing_const=0.1,
                 scaling_x=1,
                 scaling_p=3,
                 omega1=0.2
                 ):
        torch.nn.Module.__init__(self)
        # initialize proxies s.t. norm of each proxy ~1 through div by 8
        # i.e. proxies.norm(2, dim=1)) should be close to [1,1,...,1]
        # TODO: use norm instead of div 8, because of embedding size
        self.proxies = Parameter(torch.randn(nb_classes, sz_embedding) / 8)
        self.smoothing_const = smoothing_const
        self.scaling_x = scaling_x
        self.scaling_p = scaling_p
        self.estimator = EstimatorCV(sz_embedding, nb_classes)
        self.omega1 = omega1

    def calculate_loss(self, X, P, T, CoVariance, weight=0.5):
        """
        :param X:
        :param P:
        :param T:
        :param weight:当weight=0，表示正常的ProxyNCA；当weight=0.5，表示anchor为高斯采样生成的样本上界
        :return:
        """
        T_ = binarize_and_smooth_labels(T, len(P), self.smoothing_const)  ### N * C
        C, N, D = self.proxies.shape[0], X.shape[0], self.proxies.shape[1]
        Dist = 2 * F.linear(X, P)
        p_z = self.proxies
        p_y = self.proxies[T]

        # coVariance = self.estimator.CoVariance[T]
        term_bound = (4 * (p_z.view(1, C, D) - p_y.view(N, 1, D))).pow(2).mul(
            CoVariance.view(N, 1, D).expand(N, C, D)
        ).sum(2)
        loss = torch.sum(-T_ * F.log_softmax(Dist + weight * term_bound, -1), -1)  ### N * C
        return loss.mean()

    def forward(self, X, T):

        C, N, D = self.proxies.shape[0], X.shape[0], self.proxies.shape[1]
        P = F.normalize(self.proxies, p=2, dim=-1) * self.scaling_p  ###   C * D
        X = F.normalize(X, p=2, dim=-1) * self.scaling_x  ###   N * D
        self.estimator.update_CV(X.detach(), T)

        nca_loss = self.calculate_loss(X, P, T, self.estimator.CoVariance[T], weight=0.0)

        ### X混合之后的混合方差
        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(X)
        shuffledT = T[indices]
        MixedCoVariance = lam * lam * self.estimator.CoVariance[T] + (1 - lam) * (1 - lam) * self.estimator.CoVariance[shuffledT]

        ### 经过混合之后的变量模依旧为定值，说明计算公式满足calculate_loss
        mixed_loss = lam * self.calculate_loss(MixedX, P, T, MixedCoVariance) + (1 - lam) * self.calculate_loss(MixedX, P, shuffledT, MixedCoVariance)

        return nca_loss + self.omega1 * mixed_loss


if __name__ == '__main__':
    import random

    nb_classes = 5
    sz_batch = 2
    sz_embedding = 2
    X = torch.randn(sz_batch, sz_embedding).cuda()
    P = torch.randn(nb_classes, sz_embedding).cuda()
    T = torch.randint(low=0, high=nb_classes, size=[sz_batch]).cuda()
    criterion = MixedEmbeddingProxyNCA(nb_classes, sz_embedding).cuda()

    print(criterion(X, T.view(sz_batch)))