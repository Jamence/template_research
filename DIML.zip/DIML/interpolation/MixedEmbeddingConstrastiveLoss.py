'''
实现MixedEmbedding对比loss
@author:  Jamence
@contact: jamence@163.com
'''
from __future__ import absolute_import

import torch
from torch import nn
from torch.autograd import Variable
import numpy as np
from modules.mixup import Mixup


class MixedEmbeddingContrastiveLoss(nn.Module):
    def __init__(self, margin=0.5, omega1=0.2, **kwargs):
        super(MixedEmbeddingContrastiveLoss, self).__init__()
        self.margin = margin
        self.omega1 = omega1

    def forward(self, inputs, targets):
        n = inputs.size(0)
        # Compute similarity matrix
        sim_mat = torch.matmul(inputs, inputs.t())
        targets = targets
        ori_loss = list()

        for i in range(n):
            pos_pair_ = torch.masked_select(sim_mat[i], targets == targets[i])

            #  move itself
            pos_pair_ = torch.masked_select(pos_pair_, pos_pair_ < 1)
            neg_pair_ = torch.masked_select(sim_mat[i], targets != targets[i])

            pos_pair_ = torch.sort(pos_pair_)[0]
            neg_pair_ = torch.sort(neg_pair_)[0]

            neg_pair = torch.masked_select(neg_pair_, neg_pair_ > self.margin)

            neg_loss = 0

            pos_loss = torch.sum(-pos_pair_ + 1)
            if len(neg_pair) > 0:
                neg_loss = torch.sum(neg_pair)
            ori_loss.append(pos_loss + neg_loss)

        ori_loss = sum(ori_loss) / n

        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(inputs)
        mixed_sim_mat = torch.matmul(MixedX, X.t())
        mixed_loss = list()
        for i in range(n) :
            ### pos 1
            pos_pair_1 = torch.masked_select(mixed_sim_mat[i], targets == targets[i])
            pos_pair_2 = torch.masked_select(mixed_sim_mat[i], targets == targets[indices][i])
            # print(pos_pair_1, pos_pair_2)
            # pos_pair_1 = torch.masked_select(pos_pair_1, pos_pair_1 < 1)
            # pos_pair_1 = torch.masked_select(pos_pair_2, pos_pair_2 < 1)

            # pos_pair_1 = torch.sort(pos_pair_1)[0]
            # pos_pair_2 = torch.sort(pos_pair_2)[0]

            pos_loss = torch.sum(lam * (-pos_pair_1 + 1) + (1 - lam) * (-pos_pair_2 + 1))

            # pos_pair_ = lam * pos_pair_1.view(P1, 1) + (1 - lam) * pos_pair_2.view(1, P2)

            #  move itself
            # pos_pair_ = torch.masked_select(pos_pair_, pos_pair_ < 1)
            neg_pair_ = torch.masked_select(sim_mat[i], (targets != targets[i])&(targets != targets[indices][i]))

            # pos_pair_ = torch.sort(pos_pair_)[0]
            neg_pair_ = torch.sort(neg_pair_)[0]

            neg_pair = torch.masked_select(neg_pair_, neg_pair_ > self.margin)

            neg_loss = 0

            # pos_loss = torch.sum(-pos_pair_ + 1)
            if len(neg_pair) > 0:
                neg_loss = torch.sum(neg_pair)
            mixed_loss.append(pos_loss + neg_loss)

        mixed_loss = sum(mixed_loss) / n

        return ori_loss + self.omega1 * mixed_loss


def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8 * list(range(num_class))
    targets = Variable(torch.IntTensor(y_))

    print(MixedEmbeddingContrastiveLoss()(inputs, targets))


if __name__ == '__main__':
    main()
    print('Congratulations to you!')