'''
实现embdding层面的特征插值——ProxyNCA
@author:  Jamence
@contact: jamence@163.com
'''
import torch
from torch.nn import Parameter
import torch.nn.functional as F
from utils.EstimatorCV import EstimatorCV
from modules.mixup import Mixup

def binarize_and_smooth_labels(T, nb_classes, smoothing_const=0.1):
    # Optional: BNInception uses label smoothing, apply it for retraining also
    # "Rethinking the Inception Architecture for Computer Vision", p. 6
    import sklearn.preprocessing
    T = T.cpu().numpy()
    T = sklearn.preprocessing.label_binarize(
        T, classes=range(0, nb_classes)
    )
    T = T * (1 - smoothing_const)
    T[T == 0] = smoothing_const / (nb_classes - 1)
    T = torch.FloatTensor(T).cuda()
    return T

class MixedEmbeddingProxyNCA(torch.nn.Module):
    def __init__(self,
                 nb_classes,
                 sz_embedding,
                 smoothing_const=0.1,
                 scaling_x=1,
                 scaling_p=3,
                 omega1=0.2
                 ):
        torch.nn.Module.__init__(self)
        # initialize proxies s.t. norm of each proxy ~1 through div by 8
        # i.e. proxies.norm(2, dim=1)) should be close to [1,1,...,1]
        # TODO: use norm instead of div 8, because of embedding size
        self.proxies = Parameter(torch.randn(nb_classes, sz_embedding) / 8)
        self.smoothing_const = smoothing_const
        self.scaling_x = scaling_x
        self.scaling_p = scaling_p
        # self.estimator = EstimatorCV(sz_embedding, nb_classes)
        self.nb_classes = nb_classes
        self.omega1 = omega1

    def get_ori_loss(self, X, P, T):
        P = F.normalize(P, p=2, dim=-1) * self.scaling_p
        X = F.normalize(X, p=2, dim=-1) * self.scaling_x
        D = torch.cdist(X, P) ** 2
        T = binarize_and_smooth_labels(T, len(P), self.smoothing_const)  ### N * C
        # note that compared to proxy nca, positive included in denominator
        loss = torch.sum(-T * F.log_softmax(-D, -1), -1)  ### N * C
        return loss.mean()

    def get_mixed_loss_softmax(self, X, P, T):
        N = X.size(0)
        C = P.size(0)
        D = X.size(1)
        mixup = Mixup()
        X, mixed_X, lam, indices = mixup.apply(X)

        mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]  # N * D

        ### 不计算同类logits
        dist_mixedX2P = torch.cdist(F.normalize(mixed_X, p=2, dim=-1) * self.scaling_x, F.normalize(P, p=2, dim=1) * self.scaling_p) ** 2 ## N * C
        onehot1 = torch.zeros(N, C).cuda()
        onehot1.scatter_(1, T.view(-1, 1), 1)
        onehot2 = torch.zeros(N, C).cuda()
        onehot2.scatter_(1, T[indices].view(-1, 1), 1)
        onehot = 1 - (1 - onehot1) * (1 - onehot2)
        dist_mixedX2P = torch.where(onehot == 0, dist_mixedX2P, torch.zeros_like(dist_mixedX2P))  # N * C

        ### 添加mixed logits
        dist_mixedX2mixedP = torch.cdist(F.normalize(mixed_X, p=2, dim=-1) * self.scaling_x,
                                    F.normalize(mixed_P, p=2, dim=1) * self.scaling_p) ** 2  ## N * C
        dist_mixedX2mixedP_diag = dist_mixedX2mixedP.diag().unsqueeze(1)  # N * 1

        sim_mat = torch.cat((dist_mixedX2mixedP_diag, dist_mixedX2P), dim=-1)  # N * (C + 1)
        logits = sim_mat
        targetT = torch.zeros(N, dtype=torch.long)
        # targetT = torch.zeros(N, dtype=torch.long)
        targetT = binarize_and_smooth_labels(targetT, len(P)+1, self.smoothing_const)  ### N * C

        loss = torch.sum(-targetT * F.log_softmax(-logits, -1), -1)  ### N * C
        return loss.mean()

    def get_mixed_loss(self, X, P, T):
        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(X)

        MixedP = lam * P[T] + (1 - lam) * P[T[indices]]  # C * D
        AllP = torch.cat((P, MixedP), dim=0)  # 2C * D

        targetT = torch.arange(self.n_classes, self.n_classes + X.shape[0]).cuda()
        return self.get_ori_loss(MixedX, AllP, targetT)

    def calculate_loss(self, X, P, T, CoVariance, weight=0.5):
        """
        :param X:
        :param P:
        :param T:
        :param weight:当weight=0，表示正常的ProxyNCA；当weight=0.5，表示anchor为高斯采样生成的样本上界
        :return:
        """
        T_ = binarize_and_smooth_labels(T, len(P), self.smoothing_const)  ### N * C
        C, N, D = self.proxies.shape[0], X.shape[0], self.proxies.shape[1]
        Dist = 2 * F.linear(X, P)
        p_z = self.proxies
        p_y = self.proxies[T]

        # coVariance = self.estimator.CoVariance[T]
        term_bound = (4 * (p_z.view(1, C, D) - p_y.view(N, 1, D))).pow(2).mul(
            CoVariance.view(N, 1, D).expand(N, C, D)
        ).sum(2)
        loss = torch.sum(-T_ * F.log_softmax(Dist + weight * term_bound, -1), -1)  ### N * C
        return loss.mean()

    def get_loss(self, X, P, T):
        P = F.normalize(P, p=2, dim=-1) * self.scaling_p
        X = F.normalize(X, p=2, dim=-1) * self.scaling_x
        D = torch.cdist(X, P) ** 2               ### N * C
        T = binarize_and_smooth_labels(T, len(P), self.smoothing_const)  ### N * C
        # note that compared to proxy nca, positive included in denominator
        loss = torch.sum(-T * F.log_softmax(-D, -1), -1)  ### N * C
        return loss.mean()

    def forward(self, X, T):
        # P = self.proxies
        # ori_loss = self.get_loss(X, self.proxies, T)
        #
        # ### X混合之后的混合方差
        # mixup = Mixup()
        # X, MixedX, lam, indices = mixup.apply(X)
        # mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]
        # mixed_T = torch.arange(0, X.shape[0]).cuda()
        # mixed_loss = self.get_loss(MixedX, mixed_P, mixed_T)
        #
        # return ori_loss + self.omega1 * mixed_loss
        ori_loss = self.get_ori_loss(X, self.proxies, T)
        # mixed_loss = self.get_mixed_loss(X, self.proxies, T)
        mixed_loss = self.get_mixed_loss_softmax(X, self.proxies, T)
        return ori_loss + self.omega1 * mixed_loss


if __name__ == '__main__':
    import random

    nb_classes = 5
    sz_batch = 2
    sz_embedding = 2
    X = torch.randn(sz_batch, sz_embedding)
    P = torch.randn(nb_classes, sz_embedding)
    T = torch.randint(low=0, high=nb_classes, size=[sz_batch])
    criterion = MixedEmbeddingProxyNCA(nb_classes, sz_embedding)

    print(criterion(X, T.view(sz_batch)))