'''
实现embdding层面的特征插值——ProxyAnchor
@author:  Jamence
@contact: jamence@163.com
'''

import torch
import torch.nn as nn
import torch.nn.functional as F
from utils.utils import l2_norm, binarize, sample_lambdas
from torch.autograd import Variable
from modules.mixup import Mixup

class MixedEmbeddingProxyAnchor(torch.nn.Module):
    def __init__(self, nb_classes, sz_embed, mrg=0.1, alpha=32, omega1=0.2):
        torch.nn.Module.__init__(self)
        # Proxy Anchor Initialization
        self.proxies = torch.nn.Parameter(torch.randn(nb_classes, sz_embed).cuda())
        nn.init.kaiming_normal_(self.proxies, mode='fan_out')

        self.nb_classes = nb_classes
        self.sz_embed = sz_embed
        self.mrg = mrg
        self.alpha = alpha
        self.omega1 = omega1

    def get_ori_loss(self, X, P, T, nb_classes):
        cos = F.linear(l2_norm(X), l2_norm(P))  # Calcluate cosine similarity
        # print("cos is ", cos)
        P_one_hot = binarize(T=T, nb_classes=nb_classes)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / self.nb_classes
        loss = pos_term + neg_term
        # print(pos_term, neg_term)

        return loss

    def get_mixed_loss_softmax(self, X, P, T):
        N = X.size(0)
        C = P.size(0)
        D = X.size(1)
        mixup = Mixup()
        X, mixed_X, lam, indices = mixup.apply(X)

        mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]  # N * D

        ### 不计算同类logits
        dist_mixedX2P = F.normalize(mixed_X, p=2, dim=1).matmul(F.normalize(P, p=2, dim=1).t())  # N * C
        onehot1 = torch.zeros(N, C).cuda()
        onehot1.scatter_(1, T.view(-1, 1), 1)
        onehot2 = torch.zeros(N, C).cuda()
        onehot2.scatter_(1, T[indices].view(-1, 1), 1)
        onehot = 1 - (1 - onehot1) * (1 - onehot2)
        dist_mixedX2P = torch.where(onehot == 0, dist_mixedX2P, torch.zeros_like(dist_mixedX2P))  # N * C

        ### 添加mixed logits
        dist_mixedX2mixedP = F.normalize(mixed_X, p=2, dim=1).matmul(F.normalize(mixed_P, p=2, dim=1).t())  # N * N
        dist_mixedX2mixedP_diag = dist_mixedX2mixedP.diag().unsqueeze(1)  # N * 1

        sim_mat = torch.cat((dist_mixedX2mixedP_diag, dist_mixedX2P), dim=-1)  # N * (C + 1)
        cos = sim_mat
        targetT = torch.zeros(N, dtype=torch.long).cuda()
        P_one_hot = binarize(T=targetT, nb_classes=C + 1)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        # print(P_one_hot.shape, pos_exp.shape)
        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / (C + 1)
        loss = pos_term + neg_term
        return loss

    def get_mixed_loss(self, X, P, T):
        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(X)

        MixedP = lam * P[T] + (1 - lam) * P[T[indices]]  # C * D
        AllP = torch.cat((P, MixedP), dim=0)  # 2C * D

        targetT = torch.arange(self.nb_classes, self.nb_classes + X.shape[0]).cuda()
        return self.get_ori_loss(MixedX, AllP, targetT, self.nb_classes + X.shape[0])

    def get_loss(self, X, P, T, nb_classes):

        cos = F.linear(l2_norm(X), l2_norm(P))  # Calcluate cosine similarity
        # print("cos is ", cos)
        P_one_hot = binarize(T=T, nb_classes=nb_classes)
        N_one_hot = 1 - P_one_hot

        pos_exp = torch.exp(-self.alpha * (cos - self.mrg))
        neg_exp = torch.exp(self.alpha * (cos + self.mrg))

        with_pos_proxies = torch.nonzero(P_one_hot.sum(dim=0) != 0).squeeze(
            dim=1)  # The set of positive proxies of data in the batch
        num_valid_proxies = len(with_pos_proxies)  # The number of positive proxies

        # print(P_one_hot.shape, pos_exp.shape)
        P_sim_sum = torch.where(P_one_hot == 1, pos_exp, torch.zeros_like(pos_exp)).sum(dim=0)  # N * C
        N_sim_sum = torch.where(N_one_hot == 1, neg_exp, torch.zeros_like(neg_exp)).sum(dim=0)  # N * C

        pos_term = torch.log(1 + P_sim_sum).sum() / num_valid_proxies
        neg_term = torch.log(1 + N_sim_sum).sum() / self.nb_classes
        loss = pos_term + neg_term
        return loss

    def forward(self, X, T):
        # P = self.proxies
        # ori_loss = self.get_loss(X, P, T, self.nb_classes)
        #
        # mixup = Mixup()
        # inputs, out, lam, indices = mixup.apply(X)
        # N = out.shape[0]
        # # print(inputs, out, lam, indices)
        # mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]
        # mixed_T = torch.arange(0, inputs.shape[0]).cuda()
        # mixed_loss = self.get_loss(out, mixed_P, mixed_T, N)
        # # print(ori_loss, mixed_loss)
        # return ori_loss + self.omega1 * mixed_loss

        ori_loss = self.get_ori_loss(X, self.proxies, T, self.nb_classes)
        mixed_loss = self.get_mixed_loss(X, self.proxies, T)
        return ori_loss + self.omega1 * mixed_loss
        # return mixed_loss

if __name__ == "__main__" :
    data_size = 32
    input_dim = 256
    output_dim = 512
    num_class = 8
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 4 * list(range(num_class))
    targets = Variable(torch.LongTensor(y_))
    # print(inputs.shape, targets.shape, targets)

    inputs = inputs.cuda()
    targets = targets.cuda()
    print(MixedEmbeddingProxyAnchor(nb_classes=8, sz_embed=512)(inputs, targets))
    # print(Mixed_Proxy_Anchor4(nb_classes=16, sz_embed=512)(inputs, targets))
    # print(Proxy_Anchor(nb_classes=16, sz_embed=512)(inputs, targets))
