# Copyright (c) Malong Technologies Co., Ltd.
# All rights reserved.
#
# Contact: github@malong.com
#
# This source code is licensed under the LICENSE file in the root directory of this source tree.

import torch
from torch import nn
from modules.mixup import Mixup
from torch.autograd import Variable
from utils.utils import l2_norm

class MixedEmbeddingMultiSimilarityLoss(nn.Module):
    def __init__(self, scale_pos=2.0, scale_neg=50.0, omega1 = 1.0, omega2 = 0.2):
        super(MixedEmbeddingMultiSimilarityLoss, self).__init__()
        self.thresh = 0.5
        self.margin = 0.1

        self.scale_pos = scale_pos
        self.scale_neg = scale_neg
        self.omega1 = omega1
        self.omega2 = omega2

    def forward(self, feats, labels):
        assert feats.size(0) == labels.size(0), \
            f"feats.size(0): {feats.size(0)} is not equal to labels.size(0): {labels.size(0)}"
        batch_size = feats.size(0)
        # feats_norm = l2_norm(feats)
        sim_mat = torch.matmul(l2_norm(feats), torch.t(l2_norm(feats)))

        epsilon = 1e-5
        ori_loss = list()

        for i in range(batch_size):
            pos_pair_ = sim_mat[i][labels == labels[i]]
            pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
            neg_pair_ = sim_mat[i][labels != labels[i]]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
            pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]

            if len(neg_pair) < 1 or len(pos_pair) < 1:
                continue

            # weighting step
            pos_loss = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))
            ori_loss.append(pos_loss + neg_loss)

        # if len(ori_loss) == 0:
        #     return torch.zeros([], requires_grad=True)



        ori_loss = sum(ori_loss) / batch_size

        # mixed_loss = list()
        # mixup = Mixup()
        # X, MixedX, lam, indices = mixup.apply(feats)
        # # MixedX = l2_norm(MixedX)
        # sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(feats)))
        # for i in range(batch_size):
        #     pos_pair_1 = sim_mat[i][labels == labels[i]]
        #     pos_pair_2 = sim_mat[i][labels == labels[indices][i]]
        #
        #     pos_pair_1_theta = torch.acos(pos_pair_1)
        #     pos_pair_2_theta = torch.acos(pos_pair_2)
        #
        #     P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
        #     # pos_pair_ = (lam[i].item() * pos_pair_1.view(P1, 1) + (1 - lam[i].item()) * pos_pair_2.view(1, P2)).reshape(P1*P2, -1).squeeze()
        #     pos_pair_ = torch.cos(
        #         lam * pos_pair_1_theta.view(P1, 1) + (1 - lam) * pos_pair_2_theta.view(1, P2))
        #     pos_pair_ = pos_pair_.flatten()
        #     neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == labels[indices][i]))]
        #     print(pos_pair_.shape)
        #     print(neg_pair_.shape)
        #
        #     # ### pos1
        #     # if labels[i] == labels[indices][i] :
        #     #     pos_pair_ = sim_mat[i][labels == labels[i]]
        #     #     pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
        #     # else :
        #     #     pos_pair_1 = sim_mat[i][labels == labels[i]]
        #     #     pos_pair_2 = sim_mat[i][labels == labels[indices][i]]
        #     #     P1, P2 = pos_pair_1.shape[0], pos_pair_2.shape[0]
        #     #     pos_pair_ = lam * pos_pair_1.view(P1, 1) + (1 - lam) * pos_pair_2.view(1, P2)
        #     #     pos_pair_ = pos_pair_[pos_pair_ < 1 - epsilon]
        #     #     pos_pair_, _ = torch.topk(pos_pair_, k=4, largest=False)
        #     # neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == labels[indices][i]))]
        #     # # print("------------------------------------")
        #     # # print(labels == labels[i])
        #     # # print(labels == labels[indices][i])
        #     # # print(~((labels == labels[i]) | (labels == labels[indices][i])))
        #     # # print("====================================")
        #
        #     neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_)]
        #     pos_pair = pos_pair_[pos_pair_ - self.margin < max(neg_pair_)]
        #
        #
        #     if len(neg_pair) < 1 or len(pos_pair) < 1:
        #         continue
        #
        #     # weighting step
        #     pos_loss = 1.0 / self.scale_pos * torch.log(
        #         1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair - self.thresh))))
        #     neg_loss = 1.0 / self.scale_neg * torch.log(
        #         1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))
        #     mixed_loss.append(pos_loss + neg_loss)
        #
        # # if len(mixed_loss) == 0:
        # #     return torch.zeros([], requires_grad=True)
        #
        # mixed_loss = sum(mixed_loss) / batch_size
        mixed_loss = list()
        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(feats)
        # MixedX = l2_norm(MixedX)
        sim_mat = torch.matmul(l2_norm(MixedX), torch.t(l2_norm(feats)))
        for i in range(batch_size):

            pos_pair_1 = sim_mat[i][labels == labels[i]]
            pos_pair_1 = pos_pair_1[pos_pair_1 < 1 - epsilon]

            pos_pair_2 = sim_mat[i][labels == labels[indices][i]]
            pos_pair_2 = pos_pair_2[pos_pair_2 < 1 - epsilon]

            neg_pair_ = sim_mat[i][~((labels == labels[i]) | (labels == labels[indices][i]))]

            neg_pair = neg_pair_[neg_pair_ + self.margin > min(pos_pair_1)]
            neg_pair = neg_pair[neg_pair + self.margin > min(pos_pair_2)]
            pos_pair_1 = pos_pair_1[pos_pair_1 - self.margin < max(neg_pair_)]
            pos_pair_2 = pos_pair_2[pos_pair_2 - self.margin < max(neg_pair_)]

            if len(neg_pair) < 1 or len(pos_pair_1) < 1 or len(pos_pair_2) < 1 :
                continue

            # weighting step
            pos_loss_1 = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair_1 - self.thresh))))
            pos_loss_2 = 1.0 / self.scale_pos * torch.log(
                1 + torch.sum(torch.exp(-self.scale_pos * (pos_pair_2 - self.thresh))))
            neg_loss = 1.0 / self.scale_neg * torch.log(
                1 + torch.sum(torch.exp(self.scale_neg * (neg_pair - self.thresh))))
            mixed_loss.append(lam * pos_loss_1 + (1 - lam) * pos_loss_2 + neg_loss)

        mixed_loss = sum(mixed_loss) / batch_size

        return self.omega1 * ori_loss + self.omega2 * mixed_loss

def main():
    data_size = 32
    input_dim = 256
    output_dim = 256
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8 * list(range(num_class))
    targets = Variable(torch.IntTensor(y_))

    print(MixedEmbeddingMultiSimilarityLoss()(inputs, targets))

if __name__ == "__main__" :
    main()
############# ori_loss ################

