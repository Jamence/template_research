### 添加 欧氏距离
from __future__ import absolute_import
import torch
from torch import nn
from torch.autograd import Variable
import numpy as np
from batchminer import miner_distance
from batchminer import mixed_minner_distance
from modules.mixup import Mixup
import torch, torch.nn as nn, torch.nn.functional as F
from utils.utils import l2_norm

class MixedEmbeddingConstrastiveDistance(nn.Module):
    def __init__(self, pos_margin=0.0, neg_margin=1.0, omega1=0.2):
        super(MixedEmbeddingConstrastiveDistance, self).__init__()
        self.pos_margin = pos_margin
        self.neg_margin = neg_margin
        self.batchminer = miner_distance.miner_distance()
        self.mixed_batchminner = mixed_minner_distance.mixed_miner_distance()
        self.omega1 = omega1

    def forward(self, inputs, targets):
        inputs_norm = l2_norm(inputs)
        batch, labels = inputs_norm, targets
        sampled_triplets = self.batchminer(batch, labels)

        anchors = [triplet[0] for triplet in sampled_triplets]
        positives = [triplet[1] for triplet in sampled_triplets]
        negatives = [triplet[2] for triplet in sampled_triplets]

        pos_dists = torch.mean(
            F.relu(nn.PairwiseDistance(p=2)(batch[anchors, :], batch[positives, :]) - self.pos_margin))
        neg_dists = torch.mean(
            F.relu(self.neg_margin - nn.PairwiseDistance(p=2)(batch[anchors, :], batch[negatives, :])))

        ori_loss = pos_dists + neg_dists

        ### mixed
        mixup = Mixup()
        X, mixed_X, lam, indices = mixup.apply(inputs)
        mixed_X = l2_norm(mixed_X)
        X = l2_norm(X)
        sampled_triplets = self.mixed_batchminner(mixed_X, X, targets, indices, lam)
        anchors = [triplet[0] for triplet in sampled_triplets]
        positives1 = [triplet[1] for triplet in sampled_triplets]
        positives2 = [triplet[2] for triplet in sampled_triplets]
        negatives = [triplet[3] for triplet in sampled_triplets]

        pos_dists = torch.mean(
            F.relu(lam * nn.PairwiseDistance(p=2)(mixed_X[anchors, :], X[positives1, :]) + \
            (1 - lam) * nn.PairwiseDistance(p=2)(mixed_X[anchors, :], X[positives2, :]) - self.pos_margin))
        neg_dists = torch.mean(
            F.relu(self.neg_margin - nn.PairwiseDistance(p=2)(mixed_X[anchors, :], X[negatives, :])))

        mixed_loss = pos_dists + neg_dists

        return ori_loss + self.omega1 * mixed_loss

def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8*list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    print(MixedEmbeddingConstrastiveDistance()(inputs, targets))
if __name__ == '__main__':
    main()
    print('Congratulations to you!')
