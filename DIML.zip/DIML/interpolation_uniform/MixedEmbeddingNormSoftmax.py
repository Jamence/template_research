'''
实现MixedEmbeddingNormSoftmax
@author:  Jamence
@contact: jamence@163.com
'''

import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
import sklearn.preprocessing
from torch.nn.parameter import Parameter
from utils.EstimatorCV import EstimatorCV
from modules.mixup import Mixup

class MixedEmbeddingNormSoftmax(nn.Module):
    def __init__(self, input_dim, n_classes, temperature=0.05, omega1 = 0.2):
        super(MixedEmbeddingNormSoftmax, self).__init__()
        self.n_classes = n_classes
        self.proxy = Parameter(torch.Tensor(n_classes, input_dim))

        stdv = 1. / math.sqrt(self.proxy.size(1))
        self.proxy.data.uniform_(-stdv, stdv)
        self.temperature = temperature
        self.estimator = EstimatorCV(input_dim, n_classes)
        self.omega1 = omega1

    def get_ori_loss(self, X, P, T):
        X = F.normalize(X, p=2, dim=1)
        P = F.normalize(P, p=2, dim=1)

        sim_mat = X.matmul(P.t())                      # N * 2C

        logits = sim_mat / self.temperature           # N * C

        loss = F.cross_entropy(logits, T)

        return loss

    def get_mixed_loss_softmax(self, X, P, T):
        N = X.size(0)
        C = P.size(0)
        D = X.size(1)
        mixup = Mixup()
        X, mixed_X, lam, indices = mixup.apply(X)

        mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]   # N * D

        ### 不计算同类logits
        dist_mixedX2P = F.normalize(mixed_X, p=2, dim=1).matmul(F.normalize(P, p=2, dim=1).t())  # N * C
        onehot1 = torch.zeros(N, C).cuda()
        onehot1.scatter_(1, T.view(-1, 1), 1)
        onehot2 = torch.zeros(N, C).cuda()
        onehot2.scatter_(1, T[indices].view(-1, 1), 1)
        onehot = 1 - (1 - onehot1) * (1 - onehot2)
        dist_mixedX2P = torch.where(onehot==0, dist_mixedX2P, torch.zeros_like(dist_mixedX2P))  # N * C

        ### 添加mixed logits
        dist_mixedX2mixedP = F.normalize(mixed_X, p=2, dim=1).matmul(F.normalize(mixed_P, p=2, dim=1).t())  # N * N
        dist_mixedX2mixedP_diag = dist_mixedX2mixedP.diag().unsqueeze(1)  # N * 1

        sim_mat = torch.cat((dist_mixedX2mixedP_diag, dist_mixedX2P), dim = -1)  # N * (C + 1)
        logits = sim_mat / self.temperature
        targetT = torch.zeros(N, dtype=torch.long).cuda()

        loss = F.cross_entropy(logits, targetT)
        return loss

    def get_mixed_loss(self, X, P, T):
        mixup = Mixup()
        X, MixedX, lam, indices = mixup.apply(X)

        MixedP = lam * P[T] + (1 - lam) * P[T[indices]]  # C * D
        AllP = torch.cat((P, MixedP), dim=0)             # 2C * D

        targetT = torch.arange(self.n_classes, self.n_classes + X.shape[0]).cuda()
        return self.get_ori_loss(MixedX, AllP, targetT)

    def forward(self, X, T):
        # P = self.proxy
        # ori_loss = self.get_loss(X, self.proxy, T)
        #
        # mixup = Mixup()
        # X, MixedX, lam, indices = mixup.apply(X)
        #
        # mixed_P = lam * P[T] + (1 - lam) * P[T[indices]]
        # mixed_T = torch.arange(0, X.shape[0]).cuda()
        # mixed_loss = self.get_loss(MixedX, mixed_P, mixed_T)
        #
        # return ori_loss + self.omega1 * mixed_loss
        ori_loss = self.get_ori_loss(X, self.proxy, T)
        mixed_loss = self.get_mixed_loss_softmax(X, self.proxy, T)
        # print(ori_loss, mixed_loss)
        return ori_loss + self.omega1 * mixed_loss
        # return mixed_loss


if __name__ == '__main__':
    import random

    nb_classes = 5
    sz_batch = 2
    sz_embedding = 2
    X = torch.randn(sz_batch, sz_embedding).cuda()
    P = torch.randn(nb_classes, sz_embedding).cuda()
    T = torch.randint(low=0, high=nb_classes, size=[sz_batch]).cuda()
    # T = T.cpu().numpy()
    # T = sklearn.preprocessing.label_binarize(
    #     T, classes=range(0, nb_classes)
    # )
    print(T)
    criterion = MixedEmbeddingNormSoftmax(sz_embedding,nb_classes ).cuda()

    print(criterion(X, T.view(sz_batch)))