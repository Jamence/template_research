import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F
import batchminer

def euclidean_dist(x, y):
    """
    Args:
      x: pytorch Variable, with shape [m, d]
      y: pytorch Variable, with shape [n, d]
    Returns:
      dist: pytorch Variable, with shape [m, n]
    """
    m, n = x.size(0), y.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    dist.addmm_(1, -2, x, y.t())
    dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability
    return dist

class mixed_miner_distance():
    def __init__(self, miner_distance_lower_cutoff=0.5, miner_distance_upper_cutoff=1.4):
        self.lower_cutoff = miner_distance_lower_cutoff
        self.upper_cutoff = miner_distance_upper_cutoff
        self.name         = 'distance'

    def __call__(self, mixed_batch, batch, labels, indices, lam, tar_labels=None, return_distances=False, distances=None):
        if isinstance(labels, torch.Tensor): labels = labels.detach().cpu().numpy()
        bs, dim = batch.shape

        if distances is None:
            distances = euclidean_dist(mixed_batch.detach(), batch.detach()).clamp(min=self.lower_cutoff)
        sel_d = distances.shape[-1]

        positives1, positives2, negatives = [],[],[]
        anchors              = []

        tar_labels = labels if tar_labels is None else tar_labels

        for i in range(bs):
            pos1 = tar_labels == labels[i]
            pos2 = tar_labels == labels[indices][i]
            anchors.append(i)
            q_d_inv = self.inverse_sphere_distances(dim, bs, distances[i], tar_labels, labels[i], labels[indices][i])
            negatives.append(np.random.choice(sel_d,p=q_d_inv))

            pos1[i] = 0
            pos2[i] = 0
            positives1.append(np.random.choice(np.where(pos1)[0]))
            positives2.append(np.random.choice(np.where(pos2)[0]))

        sampled_triplets = [[a,p1,p2,n] for a,p1,p2,n in zip(anchors, positives1, positives2, negatives)]

        if return_distances:
            return sampled_triplets, distances
        else:
            return sampled_triplets


    def inverse_sphere_distances(self, dim, bs, anchor_to_all_dists, labels, anchor_label1, anchor_label2):
            dists  = anchor_to_all_dists

            #negated log-distribution of distances of unit sphere in dimension <dim>
            log_q_d_inv = ((2.0 - float(dim)) * torch.log(dists) - (float(dim-3) / 2) * torch.log(1.0 - 0.25 * (dists.pow(2))))
            log_q_d_inv[np.where(labels == anchor_label1)[0]] = 0
            log_q_d_inv[np.where(labels == anchor_label2)[0]] = 0

            q_d_inv     = torch.exp(log_q_d_inv - torch.max(log_q_d_inv)) # - max(log) for stability
            q_d_inv[np.where(labels == anchor_label1)[0]] = 0
            q_d_inv[np.where(labels == anchor_label2)[0]] = 0

            ### NOTE: Cutting of values with high distances made the results slightly worse. It can also lead to
            # errors where there are no available negatives (for high samples_per_class cases).
            # q_d_inv[np.where(dists.detach().cpu().numpy()>self.upper_cutoff)[0]]    = 0

            q_d_inv = q_d_inv/q_d_inv.sum()
            return q_d_inv.detach().cpu().numpy()


    def pdist(self, A):
        prod = torch.mm(A, A.t())
        norm = prod.diag().unsqueeze(1).expand_as(prod)
        res = (norm + norm.t() - 2 * prod).clamp(min = 0)
        return res.sqrt()