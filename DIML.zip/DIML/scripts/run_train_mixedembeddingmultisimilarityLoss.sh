#!/usr/bin/env bash
# --gpu-id 0 --loss MixedEmbeddingMultiSimilarityLoss --model resnet50 --embedding-size 512 --batch-size 100 --lr 1e-4 --dataset cub --warm 5 --bn-freeze 1 --lr-decay-step 5 --omega1 1.0 --omega2 0.2 --IPC 5
#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh

########################################### cub ###########################################
GPU_ID=0
LOSS=MixedEmbeddingMultiSimilarityLoss
MODEL=resnet50
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
IPC=5
OMEGA1=1.0
OMEGA2=0.0
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
MIXTYPE=mixup
OMEGA2=0.1
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
OMEGA2=0.2
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
OMEGA2=0.4
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
OMEGA2=0.6
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
OMEGA2=0.8
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}
OMEGA2=1.0
python train_test_step1.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --IPC ${IPC}