#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=5e-5
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=10
IPC=10

#echo "Start Training Proxy_Anchor baseline"
#python traijamencejamencen.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}

#MixedLOSS=Mixed_Proxy_Anchor4
#echo "Start Training Mixed_Proxy_Anchor"
#python train.py --gpu-id $GPU_ID --loss ${MixedLOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}

#Proxy_NCA=ProxyNCA
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MixedEmbeddingProxyNCA
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=ProxyAnchor
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MixedEmbeddingProxyAnchor
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=NormSoftmax
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MixedEmbeddingNormSoftmax
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=ContrastiveLoss
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MixedEmbeddingContrastiveLoss
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=TripletHard
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
Proxy_NCA=MixedEmbeddingTripletHard
python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MultiSimilarityLoss
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
#Proxy_NCA=MixedEmbeddingMultiSimilarityLoss
#python train.py --gpu-id $GPU_ID --loss ${Proxy_NCA} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --IPC ${IPC}
