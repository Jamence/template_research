#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh
########################################### cub ###########################################
### bn_inception
GPU_ID=0
LOSS=MixedProxyAnchor
MODEL=resnet50_mix
EMBEDDING_SIZE=512
BATCH_SIZE=90
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
MIXTYPE=mixup
MIXLAYER=0
OMEGA1=1.0
OMEGA2=0.0
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
OMEGA1=0.0
OMEGA2=1.0
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXTYPE=manifold-mixup
MIXLAYER=5
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXLAYER=0
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXLAYER=1
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXLAYER=2
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXLAYER=3
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
MIXLAYER=4
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2} --adv-aug ori
########################################### cub ###########################################
GPU_ID=0
LOSS=MixedProxyAnchor
MODEL=resnet50_aug
EMBEDDING_SIZE=512
BATCH_SIZE=90
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
MIXLAYER=0
MIXTYPE=no
python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER}
MIXTYPE=mixup
OMEGA1=0.1
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1}
OMEGA1=0.2
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1}
OMEGA1=0.4
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1}
OMEGA1=0.6
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1}
OMEGA1=0.8
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1}
########################################### cars ###########################################
GPU_ID=0
LOSS=MixedProxyAnchor
MODEL=resnet50_aug
EMBEDDING_SIZE=512
BATCH_SIZE=90
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
MIXTYPE=mixup
OMEGA1=1.0
OMEGA2=0.2
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}

MIXTYPE=manifold-mixup
MIXLAYER=5
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
MIXLAYER=0
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
MIXLAYER=1
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
MIXLAYER=2
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
MIXLAYER=3
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
MIXLAYER=4
#python train_mixed.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --mix-type ${MIXTYPE} --mix-layer ${MIXLAYER} --omega1 ${OMEGA1} --omega2 ${OMEGA2}
########################################### Inshop ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=Inshop
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA}
LOSS=MixedEmbeddingProxyAnchor
OMEGA1=0.2
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
OMEGA1=0.6
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
########################################### SOP ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=SOP
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA}
LOSS=MixedEmbeddingProxyAnchor
OMEGA1=1.0
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
OMEGA1=0.6
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}