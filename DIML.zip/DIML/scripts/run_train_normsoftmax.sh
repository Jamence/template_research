#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh

########################################### cub ###########################################
GPU_ID=0
LOSS=NormSoftmax
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=1e-4
DATASET=cub
WARM=1
BN_FREEZE=1
LR_DECAY_STEP=10
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --l2-norm 0  >> logs/NormSoftmax_cub.log
LOSS=MixedEmbeddingNormSoftmax
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_cub.log
########################################### cars ###########################################
GPU_ID=0
LOSS=NormSoftmax
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=1e-4
DATASET=cars
WARM=1
BN_FREEZE=1
LR_DECAY_STEP=20
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --l2-norm 0  >> logs/NormSoftmax_cars.log
LOSS=MixedEmbeddingNormSoftmax
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_cars.log
########################################### Inshop ###########################################
GPU_ID=0
LOSS=NormSoftmax
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=Inshop
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} >> logs/NormSoftmax_Inshop.log
LOSS=MixedEmbeddingNormSoftmax
OMEGA1=0.2
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0   >> logs/mixedembeddingNormSoftmax_Inshop.log
OMEGA1=0.4
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_Inshop.log
OMEGA1=0.6
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0   >> logs/mixedembeddingNormSoftmax_Inshop.log
OMEGA1=0.8
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0   >> logs/mixedembeddingNormSoftmax_Inshop.log
########################################### SOP ###########################################
GPU_ID=0
LOSS=NormSoftmax
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=SOP
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} >> logs/NormSoftmax_SOP.log
LOSS=MixedEmbeddingNormSoftmax
OMEGA1=0.2
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_SOP.log
OMEGA1=0.4
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_SOP.log
OMEGA1=0.6
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_SOP.log
OMEGA1=0.8
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --omega1 ${OMEGA1} --l2-norm 0  >> logs/mixedembeddingNormSoftmax_SOP.log