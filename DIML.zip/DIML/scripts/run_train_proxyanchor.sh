#!/usr/bin/env bash
# sed -i 's/\r//' xxx.sh

########################################### cub ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=1e-4
DATASET=cub
WARM=1
BN_FREEZE=1
LR_DECAY_STEP=10
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP}
LOSS=MixedEmbeddingProxyAnchor
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP}
########################################### cars ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=1e-4
DATASET=cars
WARM=1
BN_FREEZE=1
LR_DECAY_STEP=20
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP}
LOSS=MixedEmbeddingProxyAnchor
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP}
########################################### Inshop ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=Inshop
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA}
LOSS=MixedEmbeddingProxyAnchor
OMEGA1=0.2
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
OMEGA1=0.6
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
########################################### SOP ###########################################
GPU_ID=0
LOSS=ProxyAnchor
MODEL=bn_inception
EMBEDDING_SIZE=512
BATCH_SIZE=180
LR=6e-4
DATASET=SOP
WARM=1
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
#python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA}
LOSS=MixedEmbeddingProxyAnchor
OMEGA1=1.0
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}
OMEGA1=0.6
python train.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --omega1 ${OMEGA1}