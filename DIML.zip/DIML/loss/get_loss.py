"""
实现对损失函数的封装
"""
import torch.nn as nn
import torch
from loss.MultiSimilarityLoss import MultiSimilarityLoss

class loss(nn.Module) :
    def __init__(self, name):
        super(loss, self).__init__()
        pass

    def forward(self, x):
        pass
