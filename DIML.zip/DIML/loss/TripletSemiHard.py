### 添加 欧氏距离
from __future__ import absolute_import
import torch
from torch import nn
from torch.autograd import Variable
import numpy as np

def euclidean_dist(x, y):
    """
    Args:
      x: pytorch Variable, with shape [m, d]
      y: pytorch Variable, with shape [n, d]
    Returns:
      dist: pytorch Variable, with shape [m, n]
    """
    m, n = x.size(0), y.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    dist.addmm_(1, -2, x, y.t())
    dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability
    return dist


class TripletSemiHard(nn.Module):
    def __init__(self, beta=None, margin=0.1, **kwargs):
        super(TripletSemiHard, self).__init__()
        self.beta = beta
        self.margin = margin

    def triplet_distance(self, anchor, positive, negative):
        return torch.nn.functional.relu(
            (anchor - positive).pow(2).sum() - (anchor - negative).pow(2).sum() + self.margin)

    def pdist(self, A):
        prod = torch.mm(A, A.t())
        norm = prod.diag().unsqueeze(1).expand_as(prod)
        res = (norm + norm.t() - 2 * prod).clamp(min=0)
        return res.clamp(min=0).sqrt()

    def forward(self, inputs, targets):
        n = inputs.size(0)

        ### 取样
        distances = self.pdist(inputs.detach()).detach().cpu().numpy()
        targets = targets.cpu().numpy()
        positives, negatives, anchors = [], [], []

        for i in range(n) :
            l, d = targets[i], distances[i]
            neg = targets != l;
            pos = targets == l

            anchors.append(i)
            pos[i] = 0
            p = np.random.choice(np.where(pos)[0])
            positives.append(p)

            # Find negatives that violate tripet constraint semi-negatives
            neg_mask = np.logical_and(neg, d > d[p])
            neg_mask = np.logical_and(neg_mask, d < self.margin + d[p])
            if neg_mask.sum() > 0:
                negatives.append(np.random.choice(np.where(neg_mask)[0]))
            else:
                negatives.append(np.random.choice(np.where(neg)[0]))
        sampled_triplets = [[a, p, n] for a, p, n in zip(anchors, positives, negatives)]

        ## 计算loss
        loss = torch.stack(
            [self.triplet_distance(inputs[triplet[0], :], inputs[triplet[1], :], inputs[triplet[2], :]) for triplet in
             sampled_triplets])
        # print("haha")
        return torch.mean(loss)
    #
    #
    #
    #
    #
    # def forward(self, inputs, targets):
    #     n = inputs.size(0)
    #     sim_mat = torch.matmul(inputs, inputs.t())
    #     targets = targets
    #     base = 0.5
    #     loss = list()
    #     c = 0
    #     for i in range(n):
    #         pos_pair_ = torch.masked_select(sim_mat[i], targets==targets[i])
    #         #  move itself
    #         pos_pair_ = torch.masked_select(pos_pair_, pos_pair_ < 1)
    #         neg_pair_ = torch.masked_select(sim_mat[i], targets!=targets[i])
    #         pos_pair_ = torch.sort(pos_pair_)[0]
    #         neg_pair_ = torch.sort(neg_pair_)[0]
    #         neg_pair = torch.masked_select(neg_pair_, neg_pair_ > pos_pair_[0] - self.margin)
    #         pos_pair = torch.masked_select(pos_pair_, pos_pair_ < neg_pair_[-1] + self.margin)
    #         # pos_pair = pos_pair[1:]
    #         if len(neg_pair) < 1:
    #             c += 1
    #             continue
    #         pos_loss = torch.mean(1 - pos_pair)
    #         neg_loss = torch.mean(neg_pair)
    #         # pos_loss = torch.mean(torch.log(1 + torch.exp(-2*(pos_pair - self.margin))))
    #         # neg_loss = 0.04*torch.mean(torch.log(1 + torch.exp(50*(neg_pair - self.margin))))
    #         loss.append(pos_loss + neg_loss)
    #     loss = sum(loss)/n
    #
    #     return loss
def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8*list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    print(TripletSemiHard()(inputs, targets))
if __name__ == '__main__':
    main()
    print('Congratulations to you!')
