### 添加 欧氏距离
from __future__ import absolute_import
import torch
from torch import nn
from torch.autograd import Variable
import torch.nn.functional as F
import numpy as np

def euclidean_dist(x, y):
    """
    Args:
      x: pytorch Variable, with shape [m, d]
      y: pytorch Variable, with shape [n, d]
    Returns:
      dist: pytorch Variable, with shape [m, n]
    """
    m, n = x.size(0), y.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    dist.addmm_(1, -2, x, y.t())
    dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability
    return dist


class ConstrastiveSemiHard(nn.Module):
    def __init__(self, beta=None, margin=0.1, pos_margin=0.0, neg_margin=1.0, **kwargs):
        super(ConstrastiveSemiHard, self).__init__()
        self.beta = beta
        self.margin = margin
        self.pos_margin = pos_margin
        self.neg_margin = neg_margin

    def pdist(self, A):
        prod = torch.mm(A, A.t())
        norm = prod.diag().unsqueeze(1).expand_as(prod)
        res = (norm + norm.t() - 2 * prod).clamp(min=0)
        return res.clamp(min=0).sqrt()

    def forward(self, inputs, targets):
        n = inputs.size(0)

        ### 取样
        distances = self.pdist(inputs.detach()).detach().cpu().numpy()
        targets = targets.cpu().numpy()
        positives, negatives, anchors = [], [], []

        for i in range(n) :
            l, d = targets[i], distances[i]
            neg = targets != l;
            pos = targets == l

            anchors.append(i)
            pos[i] = 0
            p = np.random.choice(np.where(pos)[0])
            positives.append(p)

            # Find negatives that violate tripet constraint semi-negatives
            neg_mask = np.logical_and(neg, d > d[p])
            neg_mask = np.logical_and(neg_mask, d < self.margin + d[p])
            if neg_mask.sum() > 0:
                negatives.append(np.random.choice(np.where(neg_mask)[0]))
            else:
                negatives.append(np.random.choice(np.where(neg)[0]))
        sampled_triplets = [[a, p, n] for a, p, n in zip(anchors, positives, negatives)]

        ## 计算loss
        anchors = [triplet[0] for triplet in sampled_triplets]
        positives = [triplet[1] for triplet in sampled_triplets]
        negatives = [triplet[2] for triplet in sampled_triplets]

        pos_dists = torch.mean(
            F.relu(nn.PairwiseDistance(p=2)(inputs[anchors, :], inputs[positives, :]) - self.pos_margin))
        neg_dists = torch.mean(
            F.relu(self.neg_margin - nn.PairwiseDistance(p=2)(inputs[anchors, :], inputs[negatives, :])))

        loss = pos_dists + neg_dists
        return loss

def main():
    data_size = 32
    input_dim = 3
    output_dim = 2
    num_class = 4
    # margin = 0.5
    x = Variable(torch.rand(data_size, input_dim), requires_grad=False)
    # print(x)
    w = Variable(torch.rand(input_dim, output_dim), requires_grad=True)
    inputs = x.mm(w)
    y_ = 8*list(range(num_class))
    targets = Variable(torch.IntTensor(y_))
    print(ConstrastiveSemiHard()(inputs, targets))
if __name__ == '__main__':
    main()
    print('Congratulations to you!')
