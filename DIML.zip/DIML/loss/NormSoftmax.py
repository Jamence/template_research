'''
实现embdding层面的特征插值——ProxyAnchor
@author:  Jamence
@contact: jamence@163.com
'''
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init
from torch.nn.parameter import Parameter

class NormSoftMax(nn.Module):
    def __init__(self, input_dim, n_classes, temperature=0.05, ps_mu=0.0, ps_alpha=0.0):
        super(NormSoftMax, self).__init__()
        self.n_classes = n_classes
        self.proxy = Parameter(torch.Tensor(n_classes, input_dim))

        stdv = 1. / math.sqrt(self.proxy.size(1))
        self.proxy.data.uniform_(-stdv, stdv)
        self.temperature = temperature

    def forward(self, input, target):
        input_l2 = F.normalize(input, p=2, dim=1)
        proxy_l2 = F.normalize(self.proxy, p=2, dim=1)

        sim_mat = input_l2.matmul(proxy_l2.t())

        logits = sim_mat / self.temperature

        loss = F.cross_entropy(logits, target)

        return loss
