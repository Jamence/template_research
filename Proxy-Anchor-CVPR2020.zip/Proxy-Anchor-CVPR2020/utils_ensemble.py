import numpy as np
import torch
import logging
# import losses
import json
from tqdm import tqdm
import torch.nn.functional as F
import math

def BhattacharyyaDistance(u1, sigma1, u2, sigma2):

    sigma_mean = (sigma1 + sigma2) / 2.0
    sigma_inv = 1.0 / (sigma_mean)
    dis1 = torch.sum(torch.pow(u1 - u2, 2) * sigma_inv, dim=1) / 8.0
    dis2 = 0.5 * (torch.sum(torch.log(sigma_mean), dim=1) -
                  0.5 * (torch.sum(torch.log(sigma1), dim=1) + torch.sum(torch.log(sigma2), dim=1)))
    return dis1 + dis2

def HellingerDistance(u1, sigma1, u2, sigma2):

    return torch.pow(1.0 - torch.exp(-BhattacharyyaDistance(u1, sigma1, u2, sigma2)), 0.5)

def WassersteinDistance(u1, sigma1, u2, sigma2):

    dis1 = torch.sum(torch.pow(u1 - u2, 2), dim=1)
    dis2 = torch.sum(torch.pow(torch.pow(sigma1, 0.5) -
                               torch.pow(sigma2, 0.5), 2), dim=1)
    return torch.pow(dis1 + dis2, 0.5)

def GeodesicDistance(u1, sigma1, u2, sigma2):

    u_dis = torch.pow(u1 - u2, 2)
    std1 = sigma1.sqrt()
    std2 = sigma2.sqrt()

    sig_dis = torch.pow(std1 - std2, 2)
    sig_sum = torch.pow(std1 + std2, 2)
    delta = torch.div(u_dis + 2 * sig_dis, u_dis + 2 * sig_sum).sqrt()
    return torch.sum(torch.pow(torch.log((1.0 + delta) / (1.0 - delta)), 2) * 2, dim=1).sqrt()

def ForwardKLDistance(u1, sigma1, u2, sigma2):

    return -0.5 * torch.sum(torch.log(sigma1) - torch.log(sigma2) - torch.div(sigma1, sigma2)
                            - torch.div(torch.pow(u1 - u2, 2), sigma2) + 1, dim=1)

def ReverseKLDistance(u2, sigma2, u1, sigma1):

    return -0.5 * torch.sum(torch.log(sigma1) - torch.log(sigma2) - torch.div(sigma1, sigma2)
                            - torch.div(torch.pow(u1 - u2, 2), sigma2) + 1, dim=1)

def JDistance(u1, sigma1, u2, sigma2):

    return ForwardKLDistance(u1, sigma1, u2, sigma2) + ForwardKLDistance(u2, sigma2, u1, sigma1)

def cos_similarity(u1, u2) :
    return F.linear(u1, u2)

def wasserstein_distance(u1, sigma1, u2, sigma2) :
    return 2*(1-cos_similarity(u1, u2))+2*(1-cos_similarity(sigma1, sigma2))

def kl_divergence(u1, sigma1, u2, sigma2) :
    """
    https://zhuanlan.zhihu.com/p/55778595
    :param u1:
    :param sigma1:
    :param u2:
    :param sigma2:
    :return:
    """
    M, N = u1.shape[0], u2.shape[0]
    D = u1.shape[1]

    return 0.5 * (torch.pow(sigma1.view(M, 1, D).div(sigma2.view(1, N, D)),2) +
                  torch.pow(sigma2.view(1, N, D).div(sigma1.view(M, 1, D)),2) - 2 +
                  torch.pow((u1.view(M, 1, D) - u2.view(1, N, D)).div(sigma1), 2) +
                  torch.pow((u1.view(M, 1, D) - u2.view(1, N, D)).div(sigma2), 2)
                  ).sum(dim=-1)

def symmetrized_kl_divergence(u1, sigma1, u2, sigma2) :
    """
    borrow from :
    Learning Probabilistic Ordinal Embeddings for Uncertainty-Aware Regression
    :param u1:
    :param sigma1:
    :param u2:
    :param sigma2:
    :return:
    """
    M, N = u1.shape[0], u2.shape[0]
    D = u1.shape[1]
    return 0.5 * (torch.pow(sigma1.view(M, 1, D).div(sigma2.view(1, N, D)), 2) +
                  torch.pow(sigma2.view(1, N, D).div(sigma1.view(M, 1, D)), 2) - 2 +
                  torch.pow((u1.view(M, 1, D) - u2.view(1, N, D)).div(sigma1.view(M, 1, D)), 2) +
                  torch.pow((u1.view(M, 1, D) - u2.view(1, N, D)).div(sigma2.view(1, N, D)), 2)
                  ).sum(dim=-1)

def euclidean_dist(x, y):
    """
    Args:
      x: pytorch Variable, with shape [m, d]
      y: pytorch Variable, with shape [n, d]
    Returns:
      dist: pytorch Variable, with shape [m, n]
    """
    m, n = x.size(0), y.size(0)
    xx = torch.pow(x, 2).sum(1, keepdim=True).expand(m, n)
    yy = torch.pow(y, 2).sum(1, keepdim=True).expand(n, m).t()
    dist = xx + yy
    dist.addmm_(1, -2, x, y.t())
    dist = dist.clamp(min=1e-12).sqrt()  # for numerical stability
    return dist

def l2_norm(input):
    input_size = input.size()
    buffer = torch.pow(input, 2)
    normp = torch.sum(buffer, 1).add_(1e-12)
    norm = torch.sqrt(normp)
    _output = torch.div(input, norm.view(-1, 1).expand_as(input))
    output = _output.view(input_size)

    return output

def calc_recall_at_k(T, Y, k):
    """
    T : [nb_samples] (target labels)
    Y : [nb_samples x k] (k predicted labels/neighbours)
    """

    s = 0
    for t,y in zip(T,Y):
        if t in torch.Tensor(y).long()[:k]:
            s += 1
    return s / (1. * len(T))

def predict_batchwise(model, dataloader):
    device = "cuda"
    model_is_training = model.training
    model.eval()
    
    ds = dataloader.dataset
    A = [[] for i in range(len(ds[0])+1)]
    with torch.no_grad():
        # extract batches (A becomes list of samples)
        for batch in tqdm(dataloader):
            for i, J in enumerate(batch):
                # i = 0: sz_batch * images
                # i = 1: sz_batch * labels
                # i = 2: sz_batch * indices
                if i == 0:
                    # move images to device of model (approximate device)
                    output = model(J.cuda())
                    J = output[0]
                    logvar = output[1]
                    var = torch.exp(logvar)
                    std = torch.sqrt(var)

                if i == 0 :
                    for j in J:
                        A[0].append(j)
                        # print("1", j.shape)
                    for j in std :
                        A[1].append(j)
                else :
                    for j in J:
                        A[2].append(j)
    model.train()
    model.train(model_is_training) # revert to previous training state
    
    return [torch.stack(A[i]) for i in range(len(A))]

def proxy_init_calc(model, dataloader):
    nb_classes = dataloader.dataset.nb_classes()
    X, T, *_ = predict_batchwise(model, dataloader)

    proxy_mean = torch.stack([X[T==class_idx].mean(0) for class_idx in range(nb_classes)])

    return proxy_mean

def evaluate_cos(model, dataloader, type='was_dis'):
    nb_classes = dataloader.dataset.nb_classes()

    # calculate embeddings with model and get targets
    X, U, T = predict_batchwise(model, dataloader)
    X = l2_norm(X)
    U = l2_norm(U)

    if type=='cos_sim' :
        cos_sim = cos_similarity(X, X)
    elif type == 'was_dis' :
        cos_sim = -1 * wasserstein_distance(X, U, X, U)
    elif type == 'sym_kl' :
        cos_sim = -1 * symmetrized_kl_divergence(X, U, X, U)
        # print(cos_sim.shape)
        # cos_sim = cos_similarity(X, X)
        # print(cos_sim.shape)

    # if withU == False :
    #     X = l2_norm(X)
    #     euc_X = euclidean_dist(X, X) ** 2
    #     euc = euc_X
    # else :
    # R @ 1: 72.316
    # R @ 2: 81.161
    # R @ 4: 88.150
    # R @ 8: 92.826
    # R @ 16: 95.982
    # R @ 32: 97.806
    #     # X = l2_norm(X)
        # U = l2_norm(U)
        # euc_X = euclidean_dist(X, X) ** 2
        # euc_U = euclidean_dist(U, U) ** 2
        # euc = euc_X + euc_U
        # pass

    # get predictions by assigning nearest 8 neighbors with cosine
    K = 32
    Y = []
    xs = []
    
    # cos_sim = F.linear(X, X)
    # cos_sim = -euc
    Y = T[cos_sim.topk(1 + K)[1][:,1:]]
    Y = Y.float().cpu()
    
    recall = []
    for k in [1, 2, 4, 8, 16, 32]:
        r_at_k = calc_recall_at_k(T, Y, k)
        recall.append(r_at_k)
        print("R@{} : {:.3f}".format(k, 100 * r_at_k))

    return recall

def evaluate_cos_Inshop(model, query_dataloader, gallery_dataloader, type='was_dis'):
    nb_classes = query_dataloader.dataset.nb_classes()
    
    # calculate embeddings with model and get targets
    query_X, query_U, query_T = predict_batchwise(model, query_dataloader)
    gallery_X, gallery_U, gallery_T = predict_batchwise(model, gallery_dataloader)
    
    query_X = l2_norm(query_X)
    gallery_X = l2_norm(gallery_X)

    query_U = l2_norm(query_U)
    gallery_U = l2_norm(gallery_U)
    
    # get predictions by assigning nearest 8 neighbors with cosine
    K = 50
    Y = []
    xs = []

    if type == 'cos_sim':
        cos_sim = cos_similarity(query_X, gallery_X)
    elif type == 'was_dis':
        cos_sim = -1 * wasserstein_distance(query_X, query_U, gallery_X, gallery_U)

    def recall_k(cos_sim, query_T, gallery_T, k):
        m = len(cos_sim)
        match_counter = 0

        for i in range(m):
            pos_sim = cos_sim[i][gallery_T == query_T[i]]
            neg_sim = cos_sim[i][gallery_T != query_T[i]]

            thresh = torch.max(pos_sim).item()

            if torch.sum(neg_sim > thresh) < k:
                match_counter += 1
            
        return match_counter / m
    
    # calculate recall @ 1, 2, 4, 8
    recall = []
    for k in [1, 10, 20, 30, 40, 50]:
        r_at_k = recall_k(cos_sim, query_T, gallery_T, k)
        recall.append(r_at_k)
        print("R@{} : {:.3f}".format(k, 100 * r_at_k))
                
    return recall

def slice_cos(u1, sigma1, u2, sigma2, num_inslice=2000, type='cos_sim') :
    """
    分片计算
    :param u1:
    :param u2:
    :param sigma1:
    :param sigma2:
    :param slice_num:   单个分片数目
    :param type:
    :return:
    """
    M, N, D = u1.shape[0], u2.shape[0], u1.shape[1]

    slice_num = M // num_inslice
    if slice_num * num_inslice != M :
        slice_num += 1

    cos_sim = None
    for i in range(0, slice_num) :
        start_id = i * num_inslice
        end_id = (i + 1) * num_inslice
        if type == 'cos_sim':
            cos_sim_i = cos_similarity(u1[start_id: end_id], u2)
        elif type == 'was_dis':
            cos_sim_i = -1 * wasserstein_distance(u1[start_id: end_id], sigma1[start_id: end_id], u2, sigma2)
        else :
            cos_sim_i = None
            print("Error!")

        if cos_sim is None :
            cos_sim = cos_sim_i
        else :
            cos_sim = torch.cat([cos_sim, cos_sim_i], dim=0)

    return cos_sim.cpu()

def evaluate_cos_SOP(model, dataloader, type='was_dis'):
    nb_classes = dataloader.dataset.nb_classes()
    
    # calculate embeddings with model and get targets
    X, U, T = predict_batchwise(model, dataloader)
    X = l2_norm(X)
    U = l2_norm(U)
    
    # get predictions by assigning nearest 8 neighbors with cosine
    K = 1000
    Y = []
    xs = []
    us = []
    for x,u in zip(X, U):
        if len(xs)<10000:
            xs.append(x)
            us.append(u)
        else:
            xs.append(x)
            us.append(u)
            xs = torch.stack(xs,dim=0)
            us = torch.stack(us,dim=0)
            #ori###################
            # cos_sim = F.linear(xs,X)
            #new###################
            # if withU == True :
            #     euc_X = euclidean_dist(xs, X) ** 2
            #     euc_U = euclidean_dist(us, U) ** 2
            #     euc = euc_X + euc_U
            #     cos_sim = -1 * euc
            # else :
            #     euc_X = euclidean_dist(xs, X) ** 2
            #     euc = euc_X
            #     cos_sim = -1 * euc
            # R @ 1: 55.747
            # R @ 10: 71.204
            # R @ 100: 83.404
            # R @ 1000: 93.503
            # if type == 'cos_sim':
            #     cos_sim = cos_similarity(xs, X)
            # elif type == 'was_dis':
            #     cos_sim = -1 * wasserstein_distance(xs, us, X, U)
            cos_sim = slice_cos(xs, us, X, U, type=type)
            #######################
            y = T[cos_sim.topk(1 + K)[1][:,1:]]
            Y.append(y.float().cpu())
            xs = []
            us = []
            
    # Last Loop
    xs = torch.stack(xs,dim=0)
    us = torch.stack(us, dim=0)
    # ori###################
    # cos_sim = F.linear(xs,X)
    # new###################
    # if type == 'cos_sim':
    #     cos_sim = cos_similarity(xs, X)
    # elif type == 'was_dis':
    #     cos_sim = -1 * wasserstein_distance(xs, us, X, U)
    cos_sim = slice_cos(xs, us, X, U, type=type)
    #######################
    y = T[cos_sim.topk(1 + K)[1][:,1:]]
    Y.append(y.float().cpu())
    Y = torch.cat(Y, dim=0)

    # calculate recall @ 1, 2, 4, 8
    recall = []
    for k in [1, 10, 100, 1000]:
        r_at_k = calc_recall_at_k(T, Y, k)
        recall.append(r_at_k)
        print("R@{} : {:.3f}".format(k, 100 * r_at_k))
    return recall

def evaluate_cos_SOP_ori(model, dataloader):
    nb_classes = dataloader.dataset.nb_classes()

    # calculate embeddings with model and get targets
    X, U, T = predict_batchwise(model, dataloader)
    X = l2_norm(X)

    # get predictions by assigning nearest 8 neighbors with cosine
    K = 1000
    Y = []
    xs = []
    for x in X:
        if len(xs) < 10000:
            xs.append(x)
        else:
            xs.append(x)
            xs = torch.stack(xs, dim=0)
            cos_sim = F.linear(xs, X)
            y = T[cos_sim.topk(1 + K)[1][:, 1:]]
            Y.append(y.float().cpu())
            xs = []

    # Last Loop
    xs = torch.stack(xs, dim=0)
    cos_sim = F.linear(xs, X)
    y = T[cos_sim.topk(1 + K)[1][:, 1:]]
    Y.append(y.float().cpu())
    Y = torch.cat(Y, dim=0)

    # calculate recall @ 1, 2, 4, 8
    recall = []
    for k in [1, 10, 100, 1000]:
        r_at_k = calc_recall_at_k(T, Y, k)
        recall.append(r_at_k)
        print("R@{} : {:.3f}".format(k, 100 * r_at_k))
    return recall