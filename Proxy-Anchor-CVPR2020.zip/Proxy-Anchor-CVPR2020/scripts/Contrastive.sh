#!/usr/bin/env bash
#!/usr/bin/env bash
### cub ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Contrastive
MODEL=resnet50_multi
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
LR_DECAY_GAMMA=0.1
## baseline
USEDFOR=baseline
DIS_TYPE=cos_sim
K1LOSS=0
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --type ${DIS_TYPE} > ${LOGFILE}

## uncertainty_full
USEDFOR=uncertainty_full
DIS_TYPE=was_dis
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.03
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}
### cars ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Contrastive
MODEL=resnet50
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=cars
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=10
LR_DECAY_GAMMA=0.1
## baseline
USEDFOR=baseline
DIS_TYPE=cos_sim
K1LOSS=0
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --type ${DIS_TYPE} > ${LOGFILE}

## uncertainty_full
USEDFOR=uncertainty_full
DIS_TYPE=was_dis
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.03
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}