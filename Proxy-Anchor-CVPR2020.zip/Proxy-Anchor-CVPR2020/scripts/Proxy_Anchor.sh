#!/usr/bin/env bash
### cub ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=resnet50_multi
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=cub
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=5
## Baseline
USEDFOR=baseline
DIS_TYPE=cos_sim
K1LOSS=0
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --type ${DIS_TYPE} > ${LOGFILE}

## Baseline + 不确定性
USEDFOR=uncertainty_full
DIS_TYPE=cos_sim
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.03
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

### Baseline + 不确定性 + 正交正则化项
K1LOSS=0.02
ORTHO=0.1
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0.1
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

### cars ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=resnet50_multi
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=cars
WARM=5
BN_FREEZE=1
LR_DECAY_STEP=10
## Baseline
USEDFOR=baseline
K1LOSS=0
ORTHO=0
DIS_TYPE=cos_sim
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --type ${DIS_TYPE} > ${LOGFILE}

## Baseline + 不确定性
USEDFOR=uncertainty_full
DIS_TYPE=cos_sim
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.03
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

## Baseline + 不确定性 + 正交正则化项
USEDFOR=uncertainty_full
DIS_TYPE=cos_sim
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

### Inshop ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=resnet50_multi
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=1e-4
DATASET=Inshop
WARM=5
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
## Baseline
USEDFOR=baseline
K1LOSS=0
ORTHO=0
DIS_TYPE=cos_sim
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --type ${DIS_TYPE} > ${LOGFILE}

## Baseline + 不确定性
USEDFOR=uncertainty_full
DIS_TYPE=cos_sim
MAX_S=50
K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.02
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.03
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.1
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
#python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.0001
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.0005
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}

K1LOSS=0.00001
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id $GPU_ID --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} --type ${DIS_TYPE} > ${LOGFILE}
### SOP ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
GPU_ID=0
LOSS=Proxy_Anchor
MODEL=resnet50_multi
EMBEDDING_SIZE=512
BATCH_SIZE=100
LR=3e-5
DATASET=SOP
WARM=5
BN_FREEZE=0
LR_DECAY_STEP=20
LR_DECAY_GAMMA=0.25
## Baseline
USEDFOR=baseline
K1LOSS=0
ORTHO=0
MAX_S=1
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}

## Baseline + 不确定性
USEDFOR=uncertainty_full
K1LOSS=0.1
ORTHO=0
MAX_S=1
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}

K1LOSS=0.2
ORTHO=0
MAX_S=1
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}

K1LOSS=0.01
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}

K1LOSS=0.001
ORTHO=0
LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
# python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}


#K1LOSS=0.01
#ORTHO=0.1
#LOGFILE=log/${DATASET}_${MODEL}_${LOSS}_embedding${EMBEDDING_SIZE}_lr${LR}_batch${BATCH_SIZE}_usedfor_${USEDFOR}_k1Loss${K1LOSS}_ortho${ORTHO}
#python ensemble_train_std.py --gpu-id ${GPU_ID} --loss ${LOSS} --model ${MODEL} --embedding-size ${EMBEDDING_SIZE} --batch-size ${BATCH_SIZE} --lr ${LR} --dataset ${DATASET} --warm ${WARM} --bn-freeze ${BN_FREEZE} --lr-decay-step ${LR_DECAY_STEP} --lr-decay-gamma ${LR_DECAY_GAMMA} --usedfor ${USEDFOR} --k1Loss ${K1LOSS} --ortho ${ORTHO} --max_s ${MAX_S} > ${LOGFILE}